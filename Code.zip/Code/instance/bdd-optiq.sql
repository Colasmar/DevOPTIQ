BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "activities" (
	"id"	INTEGER NOT NULL,
	"shape_id"	VARCHAR(50),
	"name"	VARCHAR(200) NOT NULL,
	"description"	TEXT,
	"is_result"	BOOLEAN NOT NULL,
	"duration_minutes"	REAL DEFAULT 0,
	"delay_minutes"	REAL DEFAULT 0,
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
CREATE TABLE IF NOT EXISTS "activity_roles" (
	"activity_id"	INTEGER NOT NULL,
	"role_id"	INTEGER NOT NULL,
	"status"	VARCHAR(50) NOT NULL,
	PRIMARY KEY("activity_id","role_id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("role_id") REFERENCES "roles"("id")
);
CREATE TABLE IF NOT EXISTS "alembic_version" (
	"version_num"	VARCHAR(32) NOT NULL,
	CONSTRAINT "alembic_version_pkc" PRIMARY KEY("version_num")
);
CREATE TABLE IF NOT EXISTS "aptitudes" (
	"id"	INTEGER NOT NULL,
	"description"	TEXT NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "company_params" (
	"id"	INTEGER,
	"Js"	INTEGER DEFAULT 5,
	"Sa"	INTEGER DEFAULT 47,
	"Ja"	INTEGER DEFAULT 220,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "competencies" (
	"id"	INTEGER NOT NULL,
	"description"	TEXT NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "competency_evaluation" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"item_id"	INTEGER,
	"item_type"	VARCHAR(50),
	"eval_number"	VARCHAR(50),
	"note"	VARCHAR(10) NOT NULL,
	"created_at"	TEXT DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("id" AUTOINCREMENT),
	UNIQUE("user_id","activity_id","item_id","item_type","eval_number"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("user_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS "constraints" (
	"id"	INTEGER NOT NULL,
	"description"	TEXT NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "data" (
	"id"	INTEGER NOT NULL,
	"shape_id"	VARCHAR(50),
	"name"	VARCHAR(255) NOT NULL,
	"type"	VARCHAR(50) NOT NULL,
	"description"	TEXT,
	"layer"	VARCHAR(50),
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
CREATE TABLE IF NOT EXISTS "entities" (
	"id"	INTEGER,
	"name"	VARCHAR(200) NOT NULL,
	"description"	TEXT,
	"svg_filename"	VARCHAR(255),
	"is_active"	BOOLEAN NOT NULL DEFAULT 0,
	"created_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	"updated_at"	DATETIME DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "entreprise_settings" (
	"id"	INTEGER,
	"work_hours_per_day"	INTEGER,
	"work_days_per_week"	INTEGER,
	"work_weeks_per_year"	INTEGER,
	"work_days_per_year"	INTEGER,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "links" (
	"id"	INTEGER NOT NULL,
	"source_activity_id"	INTEGER,
	"source_data_id"	INTEGER,
	"target_activity_id"	INTEGER,
	"target_data_id"	INTEGER,
	"type"	VARCHAR(50) NOT NULL,
	"description"	TEXT,
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id"),
	FOREIGN KEY("source_activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("source_data_id") REFERENCES "data"("id"),
	FOREIGN KEY("target_activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("target_data_id") REFERENCES "data"("id")
);
CREATE TABLE IF NOT EXISTS "manager_assignments" (
	"manager_id"	INTEGER NOT NULL,
	"user_id"	INTEGER NOT NULL,
	"role_id"	INTEGER,
	PRIMARY KEY("manager_id","user_id","role_id"),
	FOREIGN KEY("manager_id") REFERENCES "users"("id"),
	FOREIGN KEY("role_id") REFERENCES "roles"("id"),
	FOREIGN KEY("user_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS "performance_personnalisee" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"content"	TEXT,
	"created_at"	TEXT,
	"updated_at"	TEXT,
	"deleted"	BOOLEAN DEFAULT 0,
	"validation_status"	TEXT NOT NULL DEFAULT 'non-validée',
	"validation_date"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "performance_personnalisee_historique" (
	"id"	INTEGER,
	"performance_id"	INTEGER NOT NULL,
	"contenu"	TEXT,
	"validation_status"	TEXT,
	"validation_date"	TEXT,
	"changed_at"	TEXT NOT NULL DEFAULT (datetime('now')),
	"changed_by"	INTEGER,
	"event"	TEXT,
	"content"	TEXT,
	"user_id"	INTEGER,
	"activity_id"	INTEGER,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("performance_id") REFERENCES "performance_personnalisee"("id")
);
CREATE TABLE IF NOT EXISTS "performances" (
	"id"	INTEGER NOT NULL,
	"name"	VARCHAR(255) NOT NULL,
	"description"	TEXT,
	"link_id"	INTEGER,
	PRIMARY KEY("id"),
	UNIQUE("link_id"),
	FOREIGN KEY("link_id") REFERENCES "links"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "prerequis_comment" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"item_type"	TEXT NOT NULL CHECK("item_type" IN ('savoir', 'savoir_faire', 'hsc')),
	"item_id"	INTEGER NOT NULL,
	"comment"	TEXT,
	"created_at"	TEXT DEFAULT (datetime('now')),
	"updated_at"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "roles" (
	"id"	INTEGER NOT NULL,
	"name"	VARCHAR(100) NOT NULL,
	"onboarding_plan"	TEXT,
	"mission_generale"	TEXT,
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	UNIQUE("name"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
CREATE TABLE IF NOT EXISTS "savoir_faires" (
	"id"	INTEGER NOT NULL,
	"description"	TEXT NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "savoirs" (
	"id"	INTEGER NOT NULL,
	"description"	TEXT NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "softskills" (
	"id"	INTEGER NOT NULL,
	"habilete"	VARCHAR(255) NOT NULL,
	"niveau"	VARCHAR(10) NOT NULL,
	"justification"	TEXT,
	"activity_id"	INTEGER NOT NULL,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "task_roles" (
	"task_id"	INTEGER NOT NULL,
	"role_id"	INTEGER NOT NULL,
	"status"	VARCHAR(50) NOT NULL,
	PRIMARY KEY("task_id","role_id"),
	FOREIGN KEY("role_id") REFERENCES "roles"("id"),
	FOREIGN KEY("task_id") REFERENCES "tasks"("id")
);
CREATE TABLE IF NOT EXISTS "task_tools" (
	"task_id"	INTEGER NOT NULL,
	"tool_id"	INTEGER NOT NULL,
	PRIMARY KEY("task_id","tool_id"),
	FOREIGN KEY("task_id") REFERENCES "tasks"("id"),
	FOREIGN KEY("tool_id") REFERENCES "tools"("id")
);
CREATE TABLE IF NOT EXISTS "tasks" (
	"id"	INTEGER NOT NULL,
	"name"	VARCHAR(255) NOT NULL,
	"description"	TEXT,
	"order"	INTEGER,
	"activity_id"	INTEGER NOT NULL,
	"duration_minutes"	REAL DEFAULT 0,
	"delay_minutes"	REAL DEFAULT 0,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id")
);
CREATE TABLE IF NOT EXISTS "time_analysis" (
	"id"	INTEGER,
	"duration"	INTEGER NOT NULL,
	"recurrence"	TEXT NOT NULL,
	"frequency"	INTEGER NOT NULL,
	"delay"	INTEGER,
	"type"	TEXT NOT NULL,
	"activity_id"	INTEGER,
	"task_id"	INTEGER,
	"nb_people"	INTEGER NOT NULL DEFAULT 1,
	"impact_unit"	TEXT,
	"delay_increase"	REAL,
	"delay_percentage"	REAL,
	"role_id"	INTEGER,
	"user_id"	INTEGER,
	PRIMARY KEY("id"),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("role_id") REFERENCES "roles"("id"),
	FOREIGN KEY("task_id") REFERENCES "tasks"("id"),
	FOREIGN KEY("user_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS "time_project" (
	"id"	INTEGER,
	"name"	TEXT,
	"created_at"	TEXT DEFAULT (datetime('now')),
	"entity_id"	INTEGER,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
CREATE TABLE IF NOT EXISTS "time_project_line" (
	"id"	INTEGER,
	"project_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"duration_minutes"	REAL NOT NULL DEFAULT 0,
	"delay_minutes"	REAL NOT NULL DEFAULT 0,
	"nb_people"	INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("project_id") REFERENCES "time_project"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "time_role_analysis" (
	"id"	INTEGER,
	"role_id"	INTEGER NOT NULL,
	"js"	INTEGER,
	"sa"	INTEGER,
	"created_at"	TEXT DEFAULT (datetime('now')),
	"name"	TEXT DEFAULT 'Analyse rôle',
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("role_id") REFERENCES "roles"("id")
);
CREATE TABLE IF NOT EXISTS "time_role_line" (
	"id"	INTEGER,
	"role_analysis_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"recurrence"	TEXT NOT NULL,
	"frequency"	INTEGER NOT NULL DEFAULT 1,
	"duration_minutes"	REAL,
	"delay_minutes"	REAL NOT NULL DEFAULT 0,
	"nb_people"	INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("role_analysis_id") REFERENCES "time_role_analysis"("id") ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS "time_weakness" (
	"id"	INTEGER,
	"activity_id"	INTEGER NOT NULL,
	"task_id"	INTEGER,
	"duration_std_minutes"	REAL NOT NULL DEFAULT 0,
	"delay_std_minutes"	REAL NOT NULL DEFAULT 0,
	"recurrence"	TEXT NOT NULL,
	"frequency"	INTEGER NOT NULL DEFAULT 1,
	"weakness"	TEXT,
	"work_added_qty"	REAL NOT NULL DEFAULT 0,
	"work_added_unit"	TEXT NOT NULL DEFAULT 'minutes',
	"wait_added_qty"	REAL NOT NULL DEFAULT 0,
	"wait_added_unit"	TEXT NOT NULL DEFAULT 'minutes',
	"prob_denom"	INTEGER NOT NULL DEFAULT 1,
	"created_at"	TEXT DEFAULT (datetime('now')),
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("activity_id") REFERENCES "activities"("id"),
	FOREIGN KEY("task_id") REFERENCES "task"("id")
);
CREATE TABLE IF NOT EXISTS "tools" (
	"id"	INTEGER NOT NULL,
	"name"	VARCHAR(255) NOT NULL,
	"description"	TEXT,
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	UNIQUE("name"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
CREATE TABLE IF NOT EXISTS "training_plan" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"role_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"plan_type"	TEXT NOT NULL,
	"plan_json"	TEXT NOT NULL,
	"created_at"	TEXT DEFAULT (datetime('now')),
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "user_activity_plans" (
	"id"	INTEGER,
	"user_id"	INTEGER NOT NULL,
	"activity_id"	INTEGER NOT NULL,
	"role_id"	INTEGER,
	"content"	TEXT NOT NULL,
	"created_at"	TEXT NOT NULL,
	"updated_at"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT),
	UNIQUE("user_id","activity_id")
);
CREATE TABLE IF NOT EXISTS "user_competencies" (
	"user_id"	INTEGER NOT NULL,
	"competency_id"	INTEGER NOT NULL,
	"evaluation_date"	DATE NOT NULL,
	"self_assessment"	INTEGER CHECK("self_assessment" BETWEEN 1 AND 3),
	PRIMARY KEY("user_id","competency_id","evaluation_date"),
	FOREIGN KEY("competency_id") REFERENCES "competencies"("id"),
	FOREIGN KEY("user_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS "user_roles" (
	"user_id"	INTEGER NOT NULL,
	"role_id"	INTEGER NOT NULL,
	PRIMARY KEY("user_id","role_id"),
	FOREIGN KEY("role_id") REFERENCES "roles"("id"),
	FOREIGN KEY("user_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS "users" (
	"id"	INTEGER NOT NULL,
	"first_name"	TEXT NOT NULL,
	"last_name"	TEXT NOT NULL,
	"age"	INTEGER,
	"email"	TEXT NOT NULL,
	"password"	TEXT NOT NULL,
	"manager_id"	INTEGER,
	"status"	TEXT NOT NULL DEFAULT 'user',
	"entity_id"	INTEGER,
	PRIMARY KEY("id"),
	FOREIGN KEY("entity_id") REFERENCES "entities"("id")
);
INSERT INTO "activities" VALUES (1,'669','Mise à jour du Web','',0,75.0,1440.0,1);
INSERT INTO "activities" VALUES (2,'672','Traitement de la demande','',0,0.0,180.0,1);
INSERT INTO "activities" VALUES (3,'674','Analyse de faisabilité','',0,20.0,120.0,1);
INSERT INTO "activities" VALUES (4,'676','Réalisation de l’offre','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (5,'679','Préparation projet','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (6,'684','Prise en compte de l’offre','',1,0.0,0.0,1);
INSERT INTO "activities" VALUES (7,'686','Cotation','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (8,'1000','Négociation de l’ offre','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (9,'1016','Test laboratoire','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (10,'1022','Comité de décision','',1,0.0,0.0,1);
INSERT INTO "activities" VALUES (11,'1025','Contrôle Qualité','',0,260.0,2880.0,1);
INSERT INTO "activities" VALUES (12,'1027','Contrôle fournisseur','',1,0.0,0.0,1);
INSERT INTO "activities" VALUES (13,'1045','Réalisation des facture','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (14,'1049','Consultation du site','',1,0.0,0.0,1);
INSERT INTO "activities" VALUES (15,'1052','Relance','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (16,'1055','Encaissement','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (18,'4','Conteneur CFF','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (21,'7','Liste de couloirs','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (25,'72','Swimlane color','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (28,'75','Couloir.75','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (31,'78','Swimlane color.78','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (34,'81','Swimlane for separation','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (37,'84','Swimlane color.84','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (40,'87','Swimlane color.87','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (43,'90','Swimlane color.90','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (46,'96','Swimlane color.96','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (49,'99','Swimlane color.99','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (52,'102','Swimlane for separation.102','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (55,'105','Swimlane for separation.105','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (58,'108','Swimlane for separation.108','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (61,'111','Swimlane for separation.111','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (64,'114','Swimlane for separation.114','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (67,'117','Swimlane for separation.117','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (70,'120','Swimlane color.120','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (73,'123','Swimlane for separation.123','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (76,'126','Swimlane color.126','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (79,'129','Swimlane for separation.129','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (82,'132','Swimlane color.132','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (85,'135','Swimlane color.135','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (88,'138','Swimlane for separation.138','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (91,'141','Swimlane for separation.141','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (94,'145','Swimlane color.145','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (97,'148','Swimlane for separation.148','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (100,'152','Swimlane color.152','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (103,'155','Swimlane for separation.155','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (106,'158','Swimlane color.158','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (109,'161','Swimlane for separation.161','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (112,'164','Swimlane color.164','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (115,'181','Swimlane for separation.181','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (118,'184','Swimlane color.184','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (121,'187','Swimlane for separation.187','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (124,'190','Swimlane color.190','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (127,'193','Swimlane for separation.193','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (130,'196','Swimlane color.196','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (133,'199','Swimlane for separation.199','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (136,'202','Swimlane color.202','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (139,'205','Swimlane for separation.205','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (142,'208','Swimlane color.208','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (145,'8','Liste de phases','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (146,'9','Séparateur','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (153,'545','D - Relation client','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (265,'662','Approbation Administration des opérations','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (317,'1057','Customer relation.1057','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (318,'1058','Administration.1058','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (319,'1059','Customer relation.1059','',0,0.0,0.0,1);
INSERT INTO "activities" VALUES (321,'1061','Big If.1061','',0,0.0,0.0,1);
INSERT INTO "activity_roles" VALUES (1,13,'Garant');
INSERT INTO "activity_roles" VALUES (7,7,'Garant');
INSERT INTO "activity_roles" VALUES (6,2,'Garant');
INSERT INTO "activity_roles" VALUES (14,111,'Garant');
INSERT INTO "activity_roles" VALUES (13,112,'Garant');
INSERT INTO "activity_roles" VALUES (16,4,'Garant');
INSERT INTO "activity_roles" VALUES (9,10,'Garant');
INSERT INTO "activity_roles" VALUES (10,2,'Garant');
INSERT INTO "activity_roles" VALUES (4,2,'Garant');
INSERT INTO "activity_roles" VALUES (5,113,'Garant');
INSERT INTO "activity_roles" VALUES (3,2,'Garant');
INSERT INTO "activity_roles" VALUES (11,13,'Garant');
INSERT INTO "activity_roles" VALUES (2,7,'Garant');
INSERT INTO "alembic_version" VALUES ('4fe1f56bda52');
INSERT INTO "aptitudes" VALUES (3,'mais nan dingue',9);
INSERT INTO "aptitudes" VALUES (4,'testsetse',2);
INSERT INTO "competencies" VALUES (7,'- Négocie fermement et de manière stratégique pour obtenir le paiement en temps opportun.',15);
INSERT INTO "competencies" VALUES (10,'- Compare les produits existants en se basant sur les résultats de tests précédemment enregistrés.',9);
INSERT INTO "competencies" VALUES (11,'- Établit une feuille de prix en se basant sur une base de prix pour assurer une évaluation précise et équitable.',7);
INSERT INTO "competencies" VALUES (12,'- Met à jour la comptabilité client et envoie la facture pour maintenir une communication efficace et une gestion financière précise.',13);
INSERT INTO "competencies" VALUES (13,'- Synthétise et compare les mesures obtenues pour garantir la qualité et la conformité des produits ou services.',11);
INSERT INTO "competencies" VALUES (20,'Assimiler la demande et les objections du client pour mieux comprendre ses besoins et attentes lors de la négociation de l''offre.',8);
INSERT INTO "competencies" VALUES (21,'Publier les pages modifiées après avoir effectué un contrôle de l\''historique et vérifié les pings.',1);
INSERT INTO "competencies" VALUES (23,'Vérifier la disponibilité des produits dans le catalogue pour assurer une réponse adéquate.',2);
INSERT INTO "competencies" VALUES (24,'Analyser la demande en identifiant les besoins spécifiques du client.',2);
INSERT INTO "competencies" VALUES (25,'Collecter les informations nécessaires pour évaluer la faisabilité de la demande.',2);
INSERT INTO "competency_evaluation" VALUES (1,111,1,5,'savoirs','1','red','2025-08-15 12:45:48.832369');
INSERT INTO "competency_evaluation" VALUES (2,111,1,5,'savoirs','2','orange','2025-08-15 12:45:48.833364');
INSERT INTO "competency_evaluation" VALUES (3,111,1,5,'savoirs','3','green','2025-08-15 12:45:48.835142');
INSERT INTO "competency_evaluation" VALUES (4,111,1,6,'savoirs','1','red','2025-08-15 12:45:48.836198');
INSERT INTO "competency_evaluation" VALUES (5,111,1,6,'savoirs','2','orange','2025-08-15 12:45:48.837198');
INSERT INTO "competency_evaluation" VALUES (6,111,1,6,'savoirs','3','orange','2025-08-15 12:45:48.838200');
INSERT INTO "competency_evaluation" VALUES (7,111,1,3,'savoir_faires','1','red','2025-08-15 12:45:48.844222');
INSERT INTO "competency_evaluation" VALUES (8,111,1,3,'savoir_faires','2','red','2025-08-15 12:45:48.845226');
INSERT INTO "competency_evaluation" VALUES (9,111,1,3,'savoir_faires','3','green','2025-08-15 12:45:48.846227');
INSERT INTO "competency_evaluation" VALUES (10,111,1,4,'savoir_faires','1','red','2025-08-15 12:45:48.847221');
INSERT INTO "competency_evaluation" VALUES (11,111,1,4,'savoir_faires','2','orange','2025-08-15 12:45:48.848737');
INSERT INTO "competency_evaluation" VALUES (12,111,1,4,'savoir_faires','3','orange','2025-08-15 12:45:48.849078');
INSERT INTO "competency_evaluation" VALUES (13,111,1,5,'savoir_faires','1','orange','2025-08-15 12:45:48.850177');
INSERT INTO "competency_evaluation" VALUES (14,111,1,5,'savoir_faires','2','red','2025-08-15 12:45:48.851179');
INSERT INTO "competency_evaluation" VALUES (15,111,1,5,'savoir_faires','3','red','2025-08-15 12:45:48.852181');
INSERT INTO "competency_evaluation" VALUES (16,111,1,6,'savoir_faires','1','green','2025-08-15 12:45:48.853179');
INSERT INTO "competency_evaluation" VALUES (17,111,1,6,'savoir_faires','2','green','2025-08-15 12:45:48.854179');
INSERT INTO "competency_evaluation" VALUES (18,111,1,6,'savoir_faires','3','green','2025-08-15 12:45:48.855979');
INSERT INTO "competency_evaluation" VALUES (19,111,1,7,'savoir_faires','1','orange','2025-08-15 12:45:48.856036');
INSERT INTO "competency_evaluation" VALUES (20,111,1,7,'savoir_faires','2','orange','2025-08-15 12:45:48.857139');
INSERT INTO "competency_evaluation" VALUES (21,111,1,7,'savoir_faires','3','green','2025-08-15 12:45:48.858136');
INSERT INTO "competency_evaluation" VALUES (22,111,1,8,'savoir_faires','1','orange','2025-08-15 12:45:48.860135');
INSERT INTO "competency_evaluation" VALUES (23,111,1,8,'savoir_faires','2','orange','2025-08-15 12:45:48.861135');
INSERT INTO "competency_evaluation" VALUES (24,111,1,8,'savoir_faires','3','orange','2025-08-15 12:45:48.862139');
INSERT INTO "competency_evaluation" VALUES (25,111,1,116,'softskills','1','red','2025-05-28 15:37:08.284222');
INSERT INTO "competency_evaluation" VALUES (26,111,1,116,'softskills','2','red','2025-05-28 15:37:08.284222');
INSERT INTO "competency_evaluation" VALUES (27,111,1,116,'softskills','3','orange','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (28,111,1,117,'softskills','1','red','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (29,111,1,117,'softskills','2','orange','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (30,111,1,117,'softskills','3','green','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (31,111,1,118,'softskills','1','red','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (32,111,1,118,'softskills','2','orange','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (33,111,1,118,'softskills','3','orange','2025-05-28 15:37:08.300058');
INSERT INTO "competency_evaluation" VALUES (34,111,1,119,'softskills','1','green','2025-05-28 15:37:08.315915');
INSERT INTO "competency_evaluation" VALUES (35,111,1,119,'softskills','2','orange','2025-05-28 15:37:08.317925');
INSERT INTO "competency_evaluation" VALUES (36,111,1,119,'softskills','3','green','2025-05-28 15:37:08.317925');
INSERT INTO "competency_evaluation" VALUES (37,111,1,NULL,NULL,'garant','green','2025-08-15 12:45:48.869816');
INSERT INTO "competency_evaluation" VALUES (38,111,1,NULL,NULL,'manager','green','2025-08-15 12:45:48.870973');
INSERT INTO "competency_evaluation" VALUES (39,111,1,NULL,NULL,'rh','orange','2025-09-11 22:57:20.358016');
INSERT INTO "competency_evaluation" VALUES (40,111,3,NULL,NULL,'manager','orange','2025-08-15 12:45:48.817671');
INSERT INTO "competency_evaluation" VALUES (41,111,4,NULL,NULL,'manager','orange','2025-12-04 12:58:46.032317');
INSERT INTO "competency_evaluation" VALUES (42,111,5,NULL,NULL,'manager','orange','2025-05-28 15:37:08.160024');
INSERT INTO "competency_evaluation" VALUES (43,111,2,NULL,NULL,'manager','red','2025-08-15 12:45:48.814569');
INSERT INTO "competency_evaluation" VALUES (44,111,7,NULL,NULL,'garant','green','2025-08-15 12:45:48.880970');
INSERT INTO "competency_evaluation" VALUES (45,111,7,NULL,NULL,'manager','green','2025-08-15 12:45:48.881972');
INSERT INTO "competency_evaluation" VALUES (46,111,4,104,'softskills','1','red','2025-05-28 15:37:08.331685');
INSERT INTO "competency_evaluation" VALUES (47,111,4,104,'softskills','2','red','2025-05-28 15:37:08.331685');
INSERT INTO "competency_evaluation" VALUES (48,111,4,104,'softskills','3','red','2025-05-28 15:37:08.331685');
INSERT INTO "competency_evaluation" VALUES (49,111,3,NULL,NULL,'garant','red','2025-12-04 12:58:46.020775');
INSERT INTO "competency_evaluation" VALUES (50,111,3,NULL,NULL,'rh','green','2025-12-04 12:58:46.030332');
INSERT INTO "competency_evaluation" VALUES (51,111,4,NULL,NULL,'garant','red','2025-08-15 12:45:48.819669');
INSERT INTO "competency_evaluation" VALUES (52,111,4,NULL,NULL,'rh','green','2025-12-04 12:58:46.033825');
INSERT INTO "competency_evaluation" VALUES (53,111,5,NULL,NULL,'garant','green','2025-05-28 15:37:08.152513');
INSERT INTO "competency_evaluation" VALUES (54,111,4,103,'softskills','1','red','2025-05-28 15:37:08.317925');
INSERT INTO "competency_evaluation" VALUES (55,111,4,103,'softskills','2','red','2025-05-28 15:37:08.331685');
INSERT INTO "competency_evaluation" VALUES (56,111,4,103,'softskills','3','red','2025-05-28 15:37:08.331685');
INSERT INTO "competency_evaluation" VALUES (57,111,4,105,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (58,111,4,105,'softskills','2','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (59,111,4,105,'softskills','3','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (60,111,4,106,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (61,111,4,106,'softskills','2','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (62,111,4,106,'softskills','3','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (63,111,4,107,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO "competency_evaluation" VALUES (64,111,4,107,'softskills','2','red','2025-05-28 15:37:08.364962');
INSERT INTO "competency_evaluation" VALUES (65,111,4,107,'softskills','3','red','2025-05-28 15:37:08.364962');
INSERT INTO "competency_evaluation" VALUES (66,111,7,NULL,NULL,'rh','red','2025-08-15 12:53:52.464392');
INSERT INTO "competency_evaluation" VALUES (67,111,5,NULL,NULL,'rh','green','2025-05-30 11:40:27.601411');
INSERT INTO "competency_evaluation" VALUES (68,111,2,NULL,NULL,'garant','red','2025-08-15 12:45:48.810719');
INSERT INTO "competency_evaluation" VALUES (69,111,2,NULL,NULL,'rh','red','2025-08-15 12:45:48.815678');
INSERT INTO "competency_evaluation" VALUES (70,111,6,NULL,NULL,'garant','red','2025-12-04 12:58:46.035840');
INSERT INTO "competency_evaluation" VALUES (71,111,6,NULL,NULL,'manager','orange','2025-08-15 12:45:48.823583');
INSERT INTO "competency_evaluation" VALUES (72,111,6,NULL,NULL,'rh','green','2025-12-04 12:58:46.036840');
INSERT INTO "competency_evaluation" VALUES (73,111,10,NULL,NULL,'garant','red','2025-08-15 12:45:48.825586');
INSERT INTO "competency_evaluation" VALUES (74,111,10,NULL,NULL,'manager','orange','2025-12-04 12:58:46.037840');
INSERT INTO "competency_evaluation" VALUES (75,111,10,NULL,NULL,'rh','green','2025-12-04 12:58:46.039839');
INSERT INTO "competency_evaluation" VALUES (76,111,16,NULL,NULL,'garant','green','2025-08-15 12:45:48.872962');
INSERT INTO "competency_evaluation" VALUES (77,111,16,NULL,NULL,'manager','green','2025-08-15 12:45:48.873968');
INSERT INTO "competency_evaluation" VALUES (78,111,2,NULL,'activities','manager','red','2025-08-15 12:45:48.884885');
INSERT INTO "competency_evaluation" VALUES (79,111,3,NULL,'activities','manager','orange','2025-08-15 12:45:48.887887');
INSERT INTO "competency_evaluation" VALUES (80,111,4,NULL,'activities','manager','green','2025-08-15 12:45:48.888885');
INSERT INTO "competency_evaluation" VALUES (81,111,6,NULL,'activities','manager','orange','2025-08-15 12:45:48.890565');
INSERT INTO "competency_evaluation" VALUES (82,111,10,NULL,'activities','manager','red','2025-08-15 12:45:48.891714');
INSERT INTO "competency_evaluation" VALUES (83,111,16,NULL,'activities','manager','green','2025-08-15 12:45:48.892727');
INSERT INTO "competency_evaluation" VALUES (84,111,7,NULL,'activities','manager','green','2025-08-15 12:45:48.893722');
INSERT INTO "competency_evaluation" VALUES (85,111,1,NULL,'activities','manager','green','2025-08-15 12:45:48.894728');
INSERT INTO "competency_evaluation" VALUES (86,111,1,4,'savoirs','2','green','2025-09-11 22:53:25.829435');
INSERT INTO "competency_evaluation" VALUES (87,111,1,12,'savoirs','1','red','2025-09-11 23:49:43.157883');
INSERT INTO "competency_evaluation" VALUES (88,111,1,12,'savoirs','2','red','2025-09-11 23:49:43.157883');
INSERT INTO "competency_evaluation" VALUES (89,111,1,12,'savoirs','3','red','2025-09-11 23:49:43.157883');
INSERT INTO "competency_evaluation" VALUES (90,111,1,7,'savoirs','2','red','2025-09-12 07:41:58.497292');
INSERT INTO "competency_evaluation" VALUES (91,111,1,3,'savoirs','2','orange','2025-09-12 17:02:01.185062');
INSERT INTO "constraints" VALUES (7,'Respecter les plannings des équipes',5);
INSERT INTO "constraints" VALUES (14,'Respecter l''ortographe',1);
INSERT INTO "constraints" VALUES (15,'Sans faute',4);
INSERT INTO "constraints" VALUES (17,'utiliser Json',1);
INSERT INTO "constraints" VALUES (18,'finalisez le projet pour le 17/05',1);
INSERT INTO "constraints" VALUES (19,'Conforme logo',4);
INSERT INTO "constraints" VALUES (20,'Respect nomenclature catalogue',2);
INSERT INTO "data" VALUES (1,'675','Lancement  de l’’analyse de faisabilité','déclenchante','','T link',1);
INSERT INTO "data" VALUES (2,'680','Lancement pré-projet','déclenchante','','T link',1);
INSERT INTO "data" VALUES (3,'681','Offre à réaliser','déclenchante','','T link',1);
INSERT INTO "data" VALUES (4,'682','Liste des composants','déclenchante','','T link',1);
INSERT INTO "data" VALUES (5,'683','Planning prévisionnel projet','nourrissante','','N link',1);
INSERT INTO "data" VALUES (6,'685','Offre','déclenchante','','T link',1);
INSERT INTO "data" VALUES (7,'687','Demande de cotation','déclenchante','','T link',1);
INSERT INTO "data" VALUES (8,'688','cotation','nourrissante','','N link',1);
INSERT INTO "data" VALUES (9,'689','Produits sélectionnés','nourrissante','','N link',1);
INSERT INTO "data" VALUES (10,'1001','Offre à suivre','déclenchante','','T link',1);
INSERT INTO "data" VALUES (11,'1002','Mise à jour du Web','Retour','','',1);
INSERT INTO "data" VALUES (12,'1003','Enquête client','nourrissante','','N link',1);
INSERT INTO "data" VALUES (14,'1005','Enquête client','nourrissante','','N link',1);
INSERT INTO "data" VALUES (15,'1017','Demande de tests qualité','déclenchante','','T link',1);
INSERT INTO "data" VALUES (16,'1018','Préparation projet','Retour','','',1);
INSERT INTO "data" VALUES (17,'1019','Test laboratoire','Retour','','',1);
INSERT INTO "data" VALUES (18,'1020','Feuille de test','nourrissante','','N link',1);
INSERT INTO "data" VALUES (19,'1021','Feuille de test','nourrissante','','N link',1);
INSERT INTO "data" VALUES (20,'1023','Résultat strétégique','nourrissante','','N link',1);
INSERT INTO "data" VALUES (21,'1024','Ajustement','déclenchante','','T link',1);
INSERT INTO "data" VALUES (22,'1026','Evaluation produit','déclenchante','','T link',1);
INSERT INTO "data" VALUES (23,'1028','Résultat contrôle produit','nourrissante','','N link',1);
INSERT INTO "data" VALUES (25,'1032','Contrôle Qualité','Retour','','',1);
INSERT INTO "data" VALUES (26,'1033','Analyse de faisabilité','Retour','','',1);
INSERT INTO "data" VALUES (28,'1035','REX','nourrissante','','N link',1);
INSERT INTO "data" VALUES (29,'1036','REX','nourrissante','','N link',1);
INSERT INTO "data" VALUES (30,'1037','Feuille de prix','nourrissante','','N link',1);
INSERT INTO "data" VALUES (31,'1043','AMDEC','nourrissante','','N link',1);
INSERT INTO "data" VALUES (32,'1044','AMDEC','nourrissante','','N link',1);
INSERT INTO "data" VALUES (33,'1046','Bon de commande','déclenchante','','T link',1);
INSERT INTO "data" VALUES (34,'1048','Demande de négociation','nourrissante','','N link',1);
INSERT INTO "data" VALUES (35,'1050','Consutation','déclenchante','','T link',1);
INSERT INTO "data" VALUES (36,'1051','Update','déclenchante','','T link',1);
INSERT INTO "data" VALUES (42,'1053','Impayés','déclenchante','','T link',1);
INSERT INTO "data" VALUES (72,'1054','Résultat labo client','nourrissante','','N link',1);
INSERT INTO "data" VALUES (91,'1056','PAiement','déclenchante','','T link',1);
INSERT INTO "data" VALUES (190,'1034','Négociation de l’ offre','Retour',NULL,NULL,1);
INSERT INTO "entities" VALUES (1,'Organisation de Test','Entité créée automatiquement lors de la migration pour conserver les données existantes.','carto01.svg',0,'2025-12-03 11:38:23','2025-12-07 20:20:11.081919');
INSERT INTO "entities" VALUES (14,'Nann','','carto.svg',1,'2025-12-07 20:20:03.178201','2025-12-07 20:20:11.140536');
INSERT INTO "entreprise_settings" VALUES (1,7,5,42,NULL);
INSERT INTO "links" VALUES (1,2,NULL,3,NULL,'déclenchante','Lancement  de l’’analyse de faisabilité',1);
INSERT INTO "links" VALUES (2,3,NULL,5,NULL,'déclenchante','Lancement pré-projet',1);
INSERT INTO "links" VALUES (3,3,NULL,4,NULL,'déclenchante','Offre à réaliser',1);
INSERT INTO "links" VALUES (4,1,NULL,3,NULL,'déclenchante','Liste des composants',1);
INSERT INTO "links" VALUES (5,5,NULL,4,NULL,'nourrissante','Planning prévisionnel projet',1);
INSERT INTO "links" VALUES (6,4,NULL,6,NULL,'déclenchante','Offre',1);
INSERT INTO "links" VALUES (7,5,NULL,7,NULL,'déclenchante','Demande de cotation',1);
INSERT INTO "links" VALUES (8,7,NULL,5,NULL,'nourrissante','cotation',1);
INSERT INTO "links" VALUES (9,5,NULL,7,NULL,'nourrissante','Produits sélectionnés',1);
INSERT INTO "links" VALUES (10,4,NULL,8,NULL,'déclenchante','Offre à suivre',1);
INSERT INTO "links" VALUES (11,8,NULL,1,NULL,'nourrissante','Enquête client',1);
INSERT INTO "links" VALUES (13,8,NULL,9,NULL,'déclenchante','Demande de tests qualité',1);
INSERT INTO "links" VALUES (14,9,NULL,5,NULL,'nourrissante','Feuille de test',1);
INSERT INTO "links" VALUES (15,10,NULL,8,NULL,'nourrissante','Résultat strétégique',1);
INSERT INTO "links" VALUES (16,8,NULL,10,NULL,'déclenchante','Ajustement',1);
INSERT INTO "links" VALUES (17,9,NULL,11,NULL,'déclenchante','Evaluation produit',1);
INSERT INTO "links" VALUES (18,11,NULL,12,NULL,'nourrissante','Résultat contrôle produit',1);
INSERT INTO "links" VALUES (19,8,NULL,3,NULL,'nourrissante','REX',1);
INSERT INTO "links" VALUES (20,7,NULL,4,NULL,'nourrissante','Feuille de prix',1);
INSERT INTO "links" VALUES (22,11,NULL,8,NULL,'nourrissante','AMDEC',1);
INSERT INTO "links" VALUES (23,10,NULL,13,NULL,'déclenchante','Bon de commande',1);
INSERT INTO "links" VALUES (24,6,NULL,8,NULL,'nourrissante','Demande de négociation',1);
INSERT INTO "links" VALUES (25,14,NULL,2,NULL,'déclenchante','Consutation',1);
INSERT INTO "links" VALUES (26,1,NULL,14,NULL,'déclenchante','Update',1);
INSERT INTO "links" VALUES (27,13,NULL,15,NULL,'déclenchante','Impayés',1);
INSERT INTO "links" VALUES (28,10,NULL,9,NULL,'nourrissante','Résultat labo client',1);
INSERT INTO "links" VALUES (29,15,NULL,16,NULL,'déclenchante','PAiement',1);
INSERT INTO "performance_personnalisee" VALUES (1,111,1,'testee','2025-06-17T17:00:25.362172','2025-06-24 13:49:36.850498',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (4,111,16,'bonjour','2025-06-18 08:57:32.866051','2025-10-01T13:57:36.490369',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (5,111,2,'test','2025-06-18 10:30:55.884103','2025-06-18 11:04:57.317083',0,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (6,111,4,'oui','2025-06-18 10:59:58.864398','2025-06-18 10:59:58.864398',0,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (7,111,16,'test','2025-06-19 10:00:33.379176','2025-06-19 10:00:43.423156',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (8,111,16,'testtttt','2025-06-19 11:06:43.503568','2025-06-19 11:06:45.238225',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (9,111,16,'cccc','2025-06-19 11:07:07.534647','2025-10-01T11:21:07.476686',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (10,111,16,'aaaaa','2025-06-19 11:07:12.821792','2025-10-01T11:21:04.398270',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (11,111,16,'ssssssssss','2025-06-19 11:07:16.195679','2025-10-01T10:44:20.992989',1,'non-validée',NULL);
INSERT INTO "performance_personnalisee" VALUES (12,111,16,'test 2 1/10/25','2025-06-19 11:07:21.126379','2025-10-01T13:24:46.689929',1,'validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (13,111,1,'respect de la nomenclature de base (débutant).','2025-06-24 13:49:14.656905','2025-10-01T13:03:59.194074',0,'validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (14,111,1,'test','2025-10-01T10:23:32.907707','2025-10-01T10:23:46.353633',1,'non-validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (15,111,16,'Bonjour tout le monde !!','2025-10-01T11:52:56.127255','2025-10-01T13:23:59.041912',0,'validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (16,111,16,'en bien de','2025-10-01T13:25:05.156366','2025-10-01T13:44:09.102841',0,'validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (17,111,16,'test suppr','2025-10-01T13:58:06.284196','2025-10-01T13:58:16.327810',1,'non-validee','2025-10-01');
INSERT INTO "performance_personnalisee" VALUES (18,111,16,'testtest','2025-10-01T14:20:50.346910','2025-10-01T14:21:23.660230',1,'non-validee','2025-10-01');
INSERT INTO "performance_personnalisee_historique" VALUES (1,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-09-12 09:19:25',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (2,14,'test 23',NULL,NULL,'2025-09-12 11:12:05',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (3,14,'te',NULL,NULL,'2025-09-12 11:12:21',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (4,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-09-12 16:54:23',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (5,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-09-12 17:03:00',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (6,13,'respect de la nomenclature de base (débutant) fin',NULL,NULL,'2025-09-12 17:03:26',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (7,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-09-12 17:03:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (8,14,'test perf 01/10/25',NULL,NULL,'2025-10-01 09:21:14',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (11,14,'test',NULL,NULL,'2025-10-01 09:31:55',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (12,12,'ffffff',NULL,NULL,'2025-10-01 10:02:00',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (13,11,'ssssssssss',NULL,NULL,'2025-10-01 10:02:02',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (14,10,'aaaaa',NULL,NULL,'2025-10-01 10:02:05',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (15,9,'cccc',NULL,NULL,'2025-10-01 10:02:07',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (16,14,'test',NULL,NULL,'2025-10-01 10:02:19',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (17,12,'ffffff',NULL,NULL,'2025-10-01 10:02:39',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (18,11,'ssssssssss',NULL,NULL,'2025-10-01 10:03:15',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (19,9,'cccc',NULL,NULL,'2025-10-01 10:03:18',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (20,10,'aaaaa',NULL,NULL,'2025-10-01 10:03:20',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (21,12,'ffffff',NULL,NULL,'2025-10-01 10:03:22',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (22,14,'test',NULL,NULL,'2025-10-01 10:03:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (23,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-10-01 10:05:14',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (24,13,'respect de la nomenclature de base (débutant)',NULL,NULL,'2025-10-01 10:23:11',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (25,14,'test',NULL,NULL,'2025-10-01 10:23:32',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (26,14,'test',NULL,NULL,'2025-10-01 10:23:46',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (27,11,'ssssssssss',NULL,NULL,'2025-10-01 10:44:21',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (28,12,'ffffff',NULL,NULL,'2025-10-01 10:44:27',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (29,10,'aaaaa',NULL,NULL,'2025-10-01 11:21:04',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (30,9,'cccc',NULL,NULL,'2025-10-01 11:21:07',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (31,12,'test 2 1/10/25',NULL,NULL,'2025-10-01 11:21:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (32,13,'respect de la nomenclature de base (débutant).',NULL,NULL,'2025-10-01 11:36:19',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (33,12,'test 2 1/10/250',NULL,NULL,'2025-10-01 11:37:18',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (34,12,'test 2 1/10/25',NULL,NULL,'2025-10-01 11:37:26',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "performance_personnalisee_historique" VALUES (35,13,NULL,'validee','2025-10-01','2025-10-01 11:47:27',NULL,'before_update','respect de la nomenclature de base (débutant) tete.',111,1);
INSERT INTO "performance_personnalisee_historique" VALUES (38,15,NULL,'non-validee','2025-10-01','2025-10-01 11:52:56',NULL,'created','Bonjour',111,16);
INSERT INTO "performance_personnalisee_historique" VALUES (39,15,NULL,'non-validee','2025-10-01','2025-10-01 11:53:06',NULL,'before_update','Bonjour',111,16);
INSERT INTO "performance_personnalisee_historique" VALUES (40,13,NULL,'validee','2025-10-01','2025-10-01 12:52:39',NULL,'before_update','respect de la nomenclature de base (débutant).',111,1);
INSERT INTO "performance_personnalisee_historique" VALUES (41,13,NULL,'validee','2025-10-01','2025-10-01 13:03:59',NULL,'before_update','respect de la nomenclature de base (débutant). test 2',111,1);
INSERT INTO "performance_personnalisee_historique" VALUES (42,15,NULL,'non-validee','2025-10-01','2025-10-01 13:11:55',NULL,'before_update','Bonjour.',111,16);
INSERT INTO "performance_personnalisee_historique" VALUES (43,15,NULL,'non-validee','2025-10-01','2025-10-01 13:23:59',NULL,'before_update','Bonjour tout le monde !!',111,16);
INSERT INTO "performance_personnalisee_historique" VALUES (44,12,NULL,'validee','2025-10-01','2025-10-01 13:24:46',NULL,'deleted','test 2 1/10/25',111,16);
INSERT INTO "performances" VALUES (3,'Respect de la nomenclature','',4);
INSERT INTO "performances" VALUES (4,'Cotation prépa','',8);
INSERT INTO "performances" VALUES (5,'Perf feuille de prix','',20);
INSERT INTO "performances" VALUES (6,'Fine sur feuille de test','',14);
INSERT INTO "performances" VALUES (7,'Sortie évaluation produit','',17);
INSERT INTO "performances" VALUES (8,'O AMDEC','',NULL);
INSERT INTO "performances" VALUES (9,'J+1','',27);
INSERT INTO "performances" VALUES (10,'Avis client','',11);
INSERT INTO "performances" VALUES (11,'Test info','',13);
INSERT INTO "performances" VALUES (12,'Pour tous','',16);
INSERT INTO "performances" VALUES (13,'ave l''équipe','',19);
INSERT INTO "performances" VALUES (14,'J+1 et humour','',26);
INSERT INTO "performances" VALUES (16,'Sous 8 jour','',6);
INSERT INTO "performances" VALUES (17,'J + 1','',7);
INSERT INTO "performances" VALUES (18,'J+1','',2);
INSERT INTO "performances" VALUES (19,'J+5','',3);
INSERT INTO "prerequis_comment" VALUES (411,111,1,'savoir',3,'autonomie','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (412,111,1,'savoir',4,'détient les bases','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (413,111,1,'savoir',5,'autonomie','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (414,111,1,'savoir',6,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (415,111,1,'savoir',8,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (416,111,1,'savoir',22,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (417,111,1,'savoir_faire',3,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (418,111,1,'savoir_faire',6,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (419,111,1,'savoir_faire',8,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (420,111,1,'hsc',126,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (421,111,1,'hsc',127,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (422,111,1,'hsc',128,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (423,111,1,'hsc',129,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (424,111,1,'hsc',130,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO "prerequis_comment" VALUES (425,111,11,'hsc',77,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (426,111,11,'hsc',78,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (427,111,11,'hsc',79,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (428,111,11,'hsc',80,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (429,111,11,'hsc',81,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (430,111,11,'hsc',82,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (431,111,11,'hsc',83,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "prerequis_comment" VALUES (432,111,11,'hsc',84,'','2025-12-04 14:50:20','2025-12-04T14:50:20.415233');
INSERT INTO "roles" VALUES (1,'manager',NULL,NULL,1);
INSERT INTO "roles" VALUES (2,'Relation clients','**1) Module de formation/entrainement :**

**Formation 1: Analyse et traitement de l''information**
- Objectifs : Développer la capacité à analyser une demande client, vérifier la disponibilité dans le catalogue, et collecter les informations nécessaires pour la faisabilité.
- Durée : 1 jour
- Méthode : Formation interactive avec des études de cas réels pour pratiquer l''analyse et le traitement de l''information. 
- Critères d''évaluation : Capacité à analyser une demande client, à vérifier la disponibilité dans le catalogue, et à collecter les informations nécessaires pour la faisabilité dans un délai donné.

**Formation 2: Auto-organisation et planification**
- Objectifs : Améliorer l''auto-organisation et la planification pour respecter les contraintes et les performances.
- Durée : 1 jour
- Méthode : Ateliers pratiques sur la gestion du temps et des ressources, et la planification des tâches.
- Critères d''évaluation : Capacité à s''auto-organiser et à planifier ses actions en tenant compte des disponibilités des équipes et des délais à respecter.

**Formation 3: Coopération et flexibilité mentale**
- Objectifs : Renforcer la coopération et la flexibilité mentale pour s''adapter aux différentes demandes des clients et trouver des solutions en cas de non-disponibilité dans le catalogue.
- Durée : 1 jour
- Méthode : Jeux de rôle et simulations pour pratiquer la coopération et la flexibilité mentale.
- Critères d''évaluation : Capacité à coopérer avec les autres membres de l''équipe et à s''adapter aux différentes demandes des clients.

**2) Retour d’Expérience (REX) :**

Une session de REX pourrait être organisée sous forme de réunion d''équipe où chaque membre partage ses expériences liées aux HSC. Par exemple, un membre de l''équipe pourrait partager comment il a géré une demande client complexe en utilisant ses compétences en analyse et traitement de l''information, et comment il a planifié ses actions pour respecter les délais. Les autres membres de l''équipe pourraient ensuite donner leur feedback et partager leurs propres expériences similaires. Cette session serait animée par un facilitateur qui guiderait la discussion et s''assurerait que tous les membres de l''équipe ont l''opportunité de partager leurs expériences.

**3) Coaching d’Équipe :**

Le coaching d''équipe pourrait se concentrer sur le renforcement de la coopération, de l''auto-organisation et de l''adaptation. Par exemple, le coach pourrait organiser des ateliers pour pratiquer ces compétences, comme des jeux de rôle où les membres de l''équipe doivent collaborer pour résoudre un problème, ou des simulations où ils doivent s''adapter à des changements inattendus. Le coach pourrait également donner des feedbacks individuels pour aider chaque membre de l''équipe à améliorer ses compétences.

**4) Parcours d’Apprentissage Autonome :**

Le parcours d''apprentissage autonome pourrait inclure des micro-formations en ligne sur les HSC, comme des vidéos ou des articles sur l''analyse et le traitement de l''information, l''auto-organisation et la planification, la coopération et la flexibilité mentale. Il pourrait également inclure des exercices pratiques pour appliquer ces compétences, comme des études de cas à analyser, des tâches à planifier, ou des situations à gérer en coopération avec d''autres. Enfin, il pourrait inclure des quiz pour évaluer la compréhension et l''application des compétences.',NULL,1);
INSERT INTO "roles" VALUES (3,'Coordination projet','Plan d''accompagnement pour le développement des habiletés sociocognitives (HSC) pour le rôle "Coordination projet"

1) Plan de développement des HSC

a) Module "Gestion de projet et Auto-organisation" - HSC visée: Auto-organisation (Niveau: 3)
Objectifs : Renforcer la capacité à organiser son travail de manière autonome, à définir ses priorités et à gérer son temps efficacement.
Durée : 2 jours
Méthode : Ateliers pratiques sur la gestion du temps et des priorités, exercices de simulation de projets.
Développement des HSC : Les participants sont amenés à organiser leur travail et à gérer leur temps dans le cadre de simulations de projets, ce qui leur permet de développer leur auto-organisation.

b) Module "Planification stratégique" - HSC visée: Planification (Niveau: 3)
Objectifs : Améliorer les compétences en matière de planification de projets, de définition d''objectifs et de mise en œuvre de plans d''action.
Durée : 2 jours
Méthode : Études de cas, jeux de rôle sur la planification de projets.
Développement des HSC : Les participants sont amenés à planifier des projets de A à Z, ce qui leur permet de développer leur compétence en matière de planification.

2) Retour d’Expérience (REX)

a) Module "Analyse et traitement de l''information" - HSC visée: Traitement de l’information (Niveau: 2)
Objectifs : Renforcer la capacité à analyser et à traiter l''information de manière efficace.
Durée : 1 jour
Méthode : Ateliers de partage d''expériences, analyse de cas réels.
Développement des HSC : Les participants sont amenés à analyser des situations réelles et à traiter l''information, ce qui leur permet de développer leur compétence en matière de traitement de l''information.

b) Module "Arbitrage et prise de décision" - HSC visée: Arbitrage (Niveau: 2)
Objectifs : Améliorer les compétences en matière d''arbitrage et de prise de décision.
Durée : 1 jour
Méthode : Jeux de rôle, études de cas.
Développement des HSC : Les participants sont amenés à prendre des décisions dans des situations simulées, ce qui leur permet de développer leur compétence en matière d''arbitrage.

3) Coaching d’Équipe

a) Module "Adaptation relationnelle et travail en équipe" - HSC visée: Adaptation relationnelle (Niveau: 2)
Objectifs : Améliorer les compétences en matière de travail en équipe et d''adaptation relationnelle.
Durée : 2 jours
Méthode : Jeux de rôle, exercices de team building.
Développement des HSC : Les participants sont amenés à travailler en équipe et à s''adapter à différentes personnalités, ce qui leur permet de développer leur compétence en matière d''adaptation relationnelle.

4) Parcours d’Apprentissage Autonome

a) Module "Conceptualisation et pensée critique" - HSC visée: Conceptualisation (Niveau: 4)
Objectifs : Renforcer la capacité à conceptualiser des idées et à penser de manière critique.
Durée : Auto-apprentissage à son rythme
Méthode : Cours en ligne, lectures recommandées, exercices pratiques.
Développement des HSC : Les participants sont amenés à conceptualiser des idées et à penser de manière critique à travers des exercices pratiques et des lectures, ce qui leur permet de développer leur compétence en matière de conceptualisation.

b) Module "Flexibilité mentale et résolution de problèmes" - HSC visée: Flexibilité mentale (Niveau: 2)
Objectifs : Améliorer la flexibilité mentale et la capacité à résoudre des problèmes.
Durée : Auto-apprentissage à son rythme
Méthode : Cours en ligne, lectures recommandées, exercices pratiques.
Développement des HSC : Les participants sont amenés à résoudre des problèmes et à faire preuve de flexibilité mentale à travers des exercices pratiques et des lectures, ce qui leur permet de développer leur compétence en matière de flexibilité mentale.

c) Module "Approche globale et vision stratégique" - HSC visée: Approche globale (Niveau: 4)
Objectifs : Renforcer la capacité à avoir une vision globale et à penser de manière stratégique.
Durée : Auto-apprentissage à son rythme
Méthode : Cours en ligne, lectures recommandées, exercices pratiques.
Développement des HSC : Les participants sont amenés à avoir une vision globale et à penser de manière stratégique à travers des exercices pratiques et des lectures, ce qui leur permet de développer leur compétence en matière d''approche globale.',NULL,1);
INSERT INTO "roles" VALUES (4,'Coster','Plan d''accompagnement pour le développement des habiletés sociocognitives (HSC) du rôle "Coster"

Partie I: Plan de développement des HSC

Module 1: Auto-organisation - Niveau: 3
Objectifs: Améliorer la capacité à planifier, prioriser et gérer efficacement le temps et les ressources.
Durée: 2 jours
Méthode: Ateliers pratiques sur la gestion du temps et des ressources, exercices de planification de projets.
Développement des HSC: Les participants apprendront à s''organiser de manière autonome, en définissant des priorités et en gérant efficacement leur temps et leurs ressources.

Module 2: Arbitrage - Niveau: 3
Objectifs: Développer la capacité à prendre des décisions équilibrées et justes.
Durée: 2 jours
Méthode: Jeux de rôle sur des situations de prise de décision, discussions de groupe sur des études de cas.
Développement des HSC: Les participants développeront leur capacité à arbitrer entre différentes options et à prendre des décisions équilibrées.

Partie II: Retour d’Expérience (REX)

Module 3: Traitement de l’information - Niveau: 3
Objectifs: Améliorer la capacité à collecter, analyser et utiliser efficacement l''information.
Durée: 2 jours
Méthode: Exercices pratiques sur la collecte et l''analyse d''informations, études de cas sur l''utilisation de l''information pour la prise de décision.
Développement des HSC: Les participants apprendront à traiter efficacement l''information, en la collectant, en l''analysant et en l''utilisant pour prendre des décisions éclairées.

Partie III: Coaching d’Équipe

Module 4: Raisonnement logique - Niveau: 2
Objectifs: Développer la capacité à résoudre des problèmes et à prendre des décisions basées sur la logique.
Durée: 2 jours
Méthode: Exercices de résolution de problèmes, discussions de groupe sur des études de cas.
Développement des HSC: Les participants développeront leur capacité à utiliser le raisonnement logique pour résoudre des problèmes et prendre des décisions.

Partie IV: Parcours d’Apprentissage Autonome

Module 5: Adaptation relationnelle - Niveau: 4
Objectifs: Améliorer la capacité à interagir efficacement avec les autres et à s''adapter à différentes situations sociales.
Durée: 3 jours
Méthode: Jeux de rôle sur des situations sociales variées, feedback et coaching individuel.
Développement des HSC: Les participants développeront leur capacité à s''adapter à différentes situations sociales et à interagir efficacement avec les autres.

Ce plan d''accompagnement vise à développer les HSC nécessaires pour le rôle de "Coster", en offrant une formation et un accompagnement ciblés sur les compétences clés nécessaires pour ce rôle.',NULL,1);
INSERT INTO "roles" VALUES (5,'Controle produit','',NULL,1);
INSERT INTO "roles" VALUES (6,'Qualité','',NULL,1);
INSERT INTO "roles" VALUES (7,'Administration','',NULL,1);
INSERT INTO "roles" VALUES (8,'Suivi des mesure qualité','Plan d''accompagnement pour le développement des habiletés sociocognitives (HSC) :

I. Plan de développement des HSC

Module 1 : Auto-évaluation - Niveau: 1
Objectif : Améliorer la capacité à évaluer ses propres performances et à identifier ses points forts et faiblesses.
Durée : 1 jour
Méthode : Exercices pratiques d''auto-évaluation, feedback de pairs et de formateurs.
Développement des HSC : L''apprenant améliore son auto-évaluation en identifiant ses points forts et faiblesses et en définissant des stratégies pour améliorer ses performances.

Module 2 : Auto-organisation - Niveau: 4
Objectif : Développer des compétences avancées en gestion du temps et en organisation personnelle.
Durée : 2 jours
Méthode : Ateliers pratiques sur la gestion du temps, l''organisation personnelle et la définition des priorités.
Développement des HSC : L''apprenant renforce son auto-organisation en développant des compétences en gestion du temps et en organisation personnelle.

II. Retour d’Expérience (REX)

Module 3 : Raisonnement logique - Niveau: 2
Objectif : Améliorer la capacité à résoudre des problèmes et à prendre des décisions basées sur la logique et les faits.
Durée : 2 jours
Méthode : Études de cas, exercices de résolution de problèmes et jeux de rôle.
Développement des HSC : L''apprenant améliore son raisonnement logique en résolvant des problèmes et en prenant des décisions basées sur la logique et les faits.

III. Coaching d’Équipe

Module 4 : Planification - Niveau: 3
Objectif : Développer des compétences en planification et en gestion de projet.
Durée : 3 jours
Méthode : Ateliers de planification de projet, jeux de rôle et feedback de pairs et de formateurs.
Développement des HSC : L''apprenant renforce sa planification en développant des compétences en planification et en gestion de projet.

IV. Parcours d’Apprentissage Autonome

Module 5 : Arbitrage - Niveau: 2
Objectif : Améliorer la capacité à arbitrer entre différentes options et à prendre des décisions.
Durée : 2 jours
Méthode : Jeux de rôle, études de cas et exercices de prise de décision.
Développement des HSC : L''apprenant améliore son arbitrage en prenant des décisions basées sur l''analyse des options disponibles.

Ce plan d''accompagnement vise à développer les HSC nécessaires pour le rôle de "Suivi des mesure qualité". Chaque module est conçu pour développer une ou plusieurs HSC spécifiques, en utilisant des méthodes pédagogiques appropriées et en offrant des opportunités pour la pratique et le feedback.',NULL,1);
INSERT INTO "roles" VALUES (9,'Facturière','Plan d''accompagnement pour le développement des habiletés sociocognitives (HSC) pour le poste de Facturière

I. Plan de développement des HSC

Module 1: Auto-régulation - Niveau: 3
Objectifs: Améliorer la capacité à contrôler ses émotions et comportements en situation de travail, à gérer le stress et à maintenir la motivation.
Durée: 4 semaines
Méthode: Ateliers de gestion du stress, exercices de pleine conscience et de méditation, coaching individuel.
Lien avec les HSC: Ce module vise directement à développer l''auto-régulation, une compétence essentielle pour gérer les situations stressantes et maintenir la performance au travail.

Module 2: Traitement de l’information - Niveau: 2
Objectifs: Améliorer la capacité à analyser et synthétiser l''information, à prendre des décisions basées sur l''information disponible.
Durée: 3 semaines
Méthode: Exercices pratiques d''analyse de données, jeux de rôle pour la prise de décision, coaching individuel.
Lien avec les HSC: Ce module vise à développer le traitement de l''information, une compétence clé pour analyser et utiliser efficacement l''information dans le travail de facturation.

II. Retour d’Expérience (REX)

Objectifs: Partager les expériences et les leçons apprises, promouvoir l''apprentissage continu.
Durée: 1 journée par mois
Méthode: Réunions d''équipe pour partager les expériences, échanges de bonnes pratiques.
Lien avec les HSC: Le REX favorise le développement de toutes les HSC en permettant aux participants de réfléchir sur leurs expériences, d''apprendre des autres et d''améliorer leurs compétences.

III. Coaching d’Équipe

Objectifs: Renforcer la cohésion d''équipe, améliorer la communication et la collaboration.
Durée: 2 heures par semaine
Méthode: Ateliers de team building, coaching de groupe.
Lien avec les HSC: Le coaching d''équipe contribue au développement de l''auto-régulation et de l''auto-organisation en améliorant la capacité à travailler en équipe et à gérer les relations interpersonnelles.

IV. Parcours d’Apprentissage Autonome

Module 1: Auto-organisation - Niveau: 3
Objectifs: Améliorer la capacité à planifier et à organiser son travail de manière autonome.
Durée: 4 semaines
Méthode: Exercices pratiques de planification, coaching individuel.
Lien avec les HSC: Ce module vise directement à développer l''auto-organisation, une compétence clé pour gérer efficacement son temps et ses tâches.

Module 2: Raisonnement logique - Niveau: 2
Objectifs: Améliorer la capacité à résoudre des problèmes et à prendre des décisions de manière logique et structurée.
Durée: 3 semaines
Méthode: Jeux de rôle pour la résolution de problèmes, exercices de logique, coaching individuel.
Lien avec les HSC: Ce module vise à développer le raisonnement logique, une compétence essentielle pour résoudre les problèmes et prendre des décisions efficaces.

Module 3: Planification - Niveau: 2
Objectifs: Améliorer la capacité à planifier et à prioriser les tâches.
Durée: 3 semaines
Méthode: Exercices pratiques de planification, coaching individuel.
Lien avec les HSC: Ce module vise à développer la planification, une compétence clé pour organiser son travail et atteindre ses objectifs.',NULL,1);
INSERT INTO "roles" VALUES (10,'Site dessinateur','',NULL,1);
INSERT INTO "roles" VALUES (11,'Support finance','',NULL,1);
INSERT INTO "roles" VALUES (12,'Utilisateur','',NULL,1);
INSERT INTO "roles" VALUES (13,'Web designer','**1) Module de formation/entrainement :**

**Formation 1 : Flexibilité mentale**
- Objectifs : Comprendre la notion de flexibilité mentale, apprendre à s''adapter aux changements et à modifier ses méthodes de travail en fonction des situations.
- Durée : 0,5 jour
- Méthode : Exercices pratiques de résolution de problèmes, jeux de rôle pour s''adapter à des situations inattendues.
- Critères d''évaluation : Capacité à s''adapter à des situations nouvelles lors d''exercices de simulation, feedback des pairs.

**Formation 2 : Synthèse et raisonnement logique**
- Objectifs : Développer la capacité à synthétiser des informations et à utiliser le raisonnement logique pour prendre des décisions.
- Durée : 1 jour
- Méthode : Exercices de synthèse d''informations, jeux de logique, études de cas.
- Critères d''évaluation : Qualité des synthèses réalisées, capacité à résoudre des problèmes logiques, application du raisonnement logique dans les études de cas.

**Formation 3 : Auto-organisation et sensibilité sociale**
- Objectifs : Améliorer la capacité à s''organiser de manière autonome et à comprendre les émotions et les besoins des autres.
- Durée : 1,5 jour
- Méthode : Ateliers de gestion du temps, exercices de mise en situation pour développer l''empathie.
- Critères d''évaluation : Amélioration de l''organisation personnelle, capacité à comprendre et à répondre aux émotions des autres.

**2) Retour d’Expérience (REX) :**

La session de REX sera axée sur l''analyse de situations vécues par les participants au cours desquelles ils ont dû faire preuve de flexibilité mentale, de synthèse, d''auto-organisation, de sensibilité sociale et de raisonnement logique. Chaque participant présentera une situation, les actions qu''il a entreprises et les résultats obtenus. Les autres participants et l''animateur donneront leur feedback et proposeront des alternatives pour améliorer les HSC. 

**3) Coaching d’Équipe :**

Pour renforcer la coopération, l’auto-organisation et l’adaptation, le coach devra :
- Encourager la communication ouverte et honnête au sein de l''équipe.
- Proposer des exercices de team building pour renforcer la coopération.
- Mettre en place des rituels d''organisation (planning hebdomadaire, réunions de suivi...).
- Encourager l''initiative personnelle et la prise de décision en équipe.
- Proposer des exercices de flexibilité mentale pour aider l''équipe à s''adapter aux changements.

**4) Parcours d’Apprentissage Autonome :**

Le parcours d''apprentissage autonome pourra inclure :
- Des micro-formations en ligne sur la flexibilité mentale, la synthèse, l''auto-organisation, la sensibilité sociale et le raisonnement logique.
- Des exercices pratiques à réaliser en autonomie pour développer ces HSC (par exemple, des exercices de synthèse d''articles, des jeux de logique...).
- Des quiz pour évaluer les progrès réalisés dans le développement de ces HSC.',NULL,1);
INSERT INTO "roles" VALUES (14,'Animateur Réseaux sociaux','',NULL,1);
INSERT INTO "roles" VALUES (15,'Intrant',NULL,NULL,1);
INSERT INTO "roles" VALUES (16,'Extrant',NULL,NULL,1);
INSERT INTO "roles" VALUES (17,'Analyse',NULL,NULL,1);
INSERT INTO "roles" VALUES (18,'Développeur',NULL,NULL,1);
INSERT INTO "roles" VALUES (19,'Testeur',NULL,NULL,1);
INSERT INTO "roles" VALUES (20,'Gestionnaire de produit',NULL,NULL,1);
INSERT INTO "roles" VALUES (110,'Développeur Web',NULL,NULL,1);
INSERT INTO "roles" VALUES (112,'Testeur QA',NULL,NULL,1);
INSERT INTO "roles" VALUES (113,'Chef de projet',NULL,NULL,1);
INSERT INTO "roles" VALUES (114,'Pilote commercial',NULL,NULL,1);
INSERT INTO "savoir_faires" VALUES (3,'Développement',1);
INSERT INTO "savoir_faires" VALUES (6,'Gestion de projet agile',1);
INSERT INTO "savoir_faires" VALUES (8,'Créer et gérer une boutique en ligne avec Shopify.',1);
INSERT INTO "savoir_faires" VALUES (16,'Effectuer des tests de contrôle qualité sur des échantillons de produits',9);
INSERT INTO "savoir_faires" VALUES (17,'Rédiger un rapport d''activité',10);
INSERT INTO "savoir_faires" VALUES (20,'Analyser les caractéristiques de la demande en utilisant le Catalogue.',3);
INSERT INTO "savoir_faires" VALUES (21,'Analyser les données d''entrée pour identifier les critères de contrôle des fournisseurs.',12);
INSERT INTO "savoir_faires" VALUES (22,'Vérifier la conformité des procédures de contrôle avec les normes en vigueur.',12);
INSERT INTO "savoir_faires" VALUES (23,'Informer les personnes sur les délais et les responsabilités via le Canal Team Projet.',5);
INSERT INTO "savoir_faires" VALUES (24,'Rédiger l''offre en respectant le template PPT Offer pour assurer une présentation cohérente.',4);
INSERT INTO "savoir_faires" VALUES (25,'Utiliser le tableau des codes produits pour vérifier la conformité des références dans l''offre.',4);
INSERT INTO "savoir_faires" VALUES (26,'test',2);
INSERT INTO "savoirs" VALUES (3,'Gestion de projet',1);
INSERT INTO "savoirs" VALUES (4,'Développement web',1);
INSERT INTO "savoirs" VALUES (5,'Analyse de données',1);
INSERT INTO "savoirs" VALUES (6,'Gestion des ressources humaines',1);
INSERT INTO "savoirs" VALUES (8,'Design Graphique',1);
INSERT INTO "savoirs" VALUES (10,'Comprendre les procédures de manipulation des échantillons dans un laboratoire de test.',9);
INSERT INTO "savoirs" VALUES (11,'Identifier les équipements de sécurité nécessaires dans un laboratoire de test.',9);
INSERT INTO "savoirs" VALUES (16,'Règles de documentation des données d''entrée et de sortie pour la traçabilité.',3);
INSERT INTO "savoirs" VALUES (17,'Normes ISO 9001 relatives à la gestion de la qualité.',12);
INSERT INTO "savoirs" VALUES (18,'Principes de gestion des risques liés aux fournisseurs.',12);
INSERT INTO "savoirs" VALUES (19,'Règles de gestion de projet selon la norme ISO 21500.',5);
INSERT INTO "savoirs" VALUES (20,'Normes de rédaction professionnelle (clarté, précision, absence de fautes)',4);
INSERT INTO "savoirs" VALUES (21,'Règles de conformité graphique (logo, mise en forme) selon la charte graphique de l''entreprise.',4);
INSERT INTO "savoirs" VALUES (22,'Normes de sécurité de l''information (protection des données, accès aux outils).',1);
INSERT INTO "savoirs" VALUES (25,'Normes de documentation et traçabilité des analyses (ex. ISO 9001).',2);
INSERT INTO "softskills" VALUES (51,'Traitement de l’information','3','',7);
INSERT INTO "softskills" VALUES (52,'Raisonnement logique','2','',7);
INSERT INTO "softskills" VALUES (53,'Adaptation relationnelle','4','',7);
INSERT INTO "softskills" VALUES (72,'Planification','3','La rigueur nécessite également une bonne planification pour s''assurer que toutes les tâches sont réalisées en temps et en heure.',9);
INSERT INTO "softskills" VALUES (73,'Auto-mobilisation','2','L''esprit d''initiative nécessite une certaine auto-mobilisation pour prendre des actions de manière proactive.',9);
INSERT INTO "softskills" VALUES (74,'Auto-organisation','3','La rigueur implique une bonne organisation personnelle pour gérer les tâches de manière efficace et précise.',9);
INSERT INTO "softskills" VALUES (75,'Arbitrage','2','L''esprit d''initiative peut également impliquer de faire des choix et des décisions, ce qui nécessite des compétences en arbitrage.',9);
INSERT INTO "softskills" VALUES (76,'Raisonnement logique','2','La rigueur et l''esprit d''initiative nécessitent tous deux un raisonnement logique pour résoudre les problèmes et prendre des décisions.',9);
INSERT INTO "softskills" VALUES (77,'Auto-organisation','3','Un niveau élevé d''auto-organisation est nécessaire pour préparer les conditions de test, exécuter les mesures demandées et établir les relevés de mesure de manière efficace et ordonnée.',11);
INSERT INTO "softskills" VALUES (78,'Flexibilité mentale','2','La flexibilité mentale peut être utile pour s''adapter à différentes situations de test et pour traiter des données variables. Un niveau intermédiaire est suffisant pour cette activité.',11);
INSERT INTO "softskills" VALUES (79,'Synthèse','4','La capacité de synthétiser les informations est essentielle pour cette activité, en particulier lors de la réalisation de la synthèse comparative des mesures. Un niveau d''excellence est donc recommandé.',11);
INSERT INTO "softskills" VALUES (80,'Raisonnement logique','3','La tâche d''établir les relevés de mesure et de faire la synthèse comparative des mesures nécessite un bon niveau de raisonnement logique pour analyser et interpréter correctement les données.',11);
INSERT INTO "softskills" VALUES (81,'Auto-régulation jeunesse','1 (aptitude)','L''autorité nécessite une auto-régulation pour maintenir un équilibre entre l''assertivité et la sensibilité aux besoins des autres.',11);
INSERT INTO "softskills" VALUES (82,'Arbitrage','2','L''autorité nécessite des compétences en arbitrage pour prendre des décisions équilibrées et justes.',11);
INSERT INTO "softskills" VALUES (83,'Sensibilité sociale','1','L''autorité nécessite une certaine sensibilité sociale pour comprendre et répondre aux besoins et aux attentes des autres.',11);
INSERT INTO "softskills" VALUES (84,'Planification','2','La rigueur nécessite une bonne planification pour s''assurer que les tâches sont réalisées de manière ordonnée et dans les délais.',11);
INSERT INTO "softskills" VALUES (90,'Sensibilité sociale','4','L''humour nécessite une compréhension profonde des sentiments, des réactions et des perspectives des autres. Il faut être capable de percevoir ce qui peut faire rire les autres et de s''adapter à différents publics.',13);
INSERT INTO "softskills" VALUES (91,'Auto-évaluation','2','L''utilisation de l''humour nécessite une certaine auto-évaluation pour comprendre quand et comment l''utiliser de manière appropriée. Il faut être capable de juger si une blague ou une remarque humoristique sera bien reçue ou non.',13);
INSERT INTO "softskills" VALUES (92,'Flexibilité mentale','3','L''humour nécessite souvent de penser de manière créative et de faire des liens inattendus. Une flexibilité mentale élevée permet de créer des blagues et des jeux de mots originaux.',13);
INSERT INTO "softskills" VALUES (93,'Auto-régulation','2','L''humour nécessite une auto-régulation pour éviter de faire des blagues inappropriées ou offensantes. Il faut être capable de contrôler ses impulsions et de réfléchir avant de parler.',13);
INSERT INTO "softskills" VALUES (94,'Adaptation relationnelle','3','L''humour peut être un outil puissant pour établir des relations, mais il nécessite une capacité d''adaptation pour être utilisé efficacement. Il faut être capable de moduler son humour en fonction de la situation et des personnes présentes.',13);
INSERT INTO "softskills" VALUES (95,'Auto-organisation','3','La tâche nécessite une bonne organisation pour gérer efficacement les bons de commande, la facturation et la mise à jour de la comptabilité client. Un niveau de maîtrise est donc nécessaire.',13);
INSERT INTO "softskills" VALUES (96,'Traitement de l’information','2','La tâche implique de traiter des informations provenant de différentes sources (bon de commande, facture, base fournisseurs). Un niveau d''acquisition est suffisant car bien que le traitement de l''information soit nécessaire, il ne s''agit pas de l''aspect le plus complexe de la tâche.',13);
INSERT INTO "softskills" VALUES (97,'Raisonnement logique','3','La tâche implique de rapprocher le bon de commande de la facture et de vérifier le fournisseur, ce qui nécessite un raisonnement logique pour identifier les erreurs ou les incohérences. Un niveau de maîtrise est donc approprié.',13);
INSERT INTO "softskills" VALUES (108,'Auto-évaluation','3 (maîtrise)','L''auto-évaluation est essentielle pour la tâche T1 (Prise en compte de la demande et des objections du client) afin de comprendre ses propres forces et faiblesses dans la négociation. Cela contribue également à la performance P1 (Information à jour) en permettant une évaluation continue de l''efficacité de la négociation.',8);
INSERT INTO "softskills" VALUES (109,'Adaptation relationnelle','4 (expertise)','L''adaptation relationnelle est cruciale pour la tâche T3 (Négociation avec le client) pour s''adapter aux besoins et aux attentes du client. Cela aide également à atteindre la performance P2 (Négociation <15%) en permettant une négociation efficace.',8);
INSERT INTO "softskills" VALUES (110,'Flexibilité mentale','2 (acquisition)','La flexibilité mentale est utile pour la tâche T3 (Négociation avec le client) pour s''adapter aux changements et aux imprévus lors de la négociation. Cela aide également à atteindre la performance P2 (Négociation <15%) en permettant une négociation flexible et efficace.',8);
INSERT INTO "softskills" VALUES (111,'Synthèse','3 (maîtrise)','La synthèse est importante pour la tâche T4 (Faire le compte rendu de négo) pour résumer efficacement les points clés de la négociation. Cela contribue également à la performance P1 (Information à jour) en garantissant que toutes les informations pertinentes sont communiquées de manière concise.',8);
INSERT INTO "softskills" VALUES (112,'Raisonnement logique','2 (acquisition)','Le raisonnement logique est nécessaire pour la tâche T2 (Construction d''un argumentaire) pour développer un argumentaire solide et convaincant. Cela contribue également à la performance P3 (Liste exhaustive à jour) en assurant que tous les points pertinents sont pris en compte dans l''argumentaire.',8);
INSERT INTO "softskills" VALUES (113,'Raisonnement logique','3 (Maîtrise)','La qualité de rigueur est couverte par cette habileté. Dans la tâche T1, vérifier avec le client la raison du retard de paiement nécessite un raisonnement logique pour comprendre les raisons du retard et proposer des solutions appropriées.',15);
INSERT INTO "softskills" VALUES (114,'Auto-régulation','3 (Maîtrise)','La qualité de fermeté est couverte par cette habileté. Dans la tâche T2, la négociation ferme pour obtenir le paiement nécessite une auto-régulation pour maintenir une position ferme sans être agressif ou désobligeant.',15);
INSERT INTO "softskills" VALUES (115,'Auto-mobilisation','4 (Excellence)','La qualité de conviction est couverte par cette habileté. Dans la tâche T2, négocier fermement pour obtenir le paiement nécessite une auto-mobilisation pour convaincre le client de l''importance du paiement en temps opportun, contribuant ainsi à la performance P1 de 95% de paiements sous 30 jours.',15);
INSERT INTO "softskills" VALUES (131,'Synthèse','3 (Maîtrise)','L''esprit de synthèse est essentiel pour effectuer la tâche T4, qui consiste à établir le planning des parties prenantes. Il permet de rassembler et d''organiser efficacement les informations nécessaires pour respecter la contrainte C1, qui est de respecter les plannings des équipes.',5);
INSERT INTO "softskills" VALUES (132,'Conceptualisation','2 (Acquisition)','L''esprit systémique, qui est une forme de conceptualisation, est nécessaire pour la tâche T2, qui consiste à identifier l''équipe projet. Cela permet de comprendre comment les différentes parties du projet interagissent entre elles et comment elles peuvent être affectées par les différentes contraintes.',5);
INSERT INTO "softskills" VALUES (133,'Coopération','1 (Initiation)','La coopération est nécessaire pour toutes les tâches, car elles impliquent toutes de travailler avec d''autres personnes. Cela est particulièrement important pour la tâche T4, qui consiste à établir le planning des parties prenantes, car cela nécessite de travailler en étroite collaboration avec toutes les parties prenantes pour s''assurer que leurs disponibilités sont prises en compte.',5);
INSERT INTO "softskills" VALUES (134,'Adaptation relationnelle','3 (Maîtrise)','Une bonne communication, qui est une forme d''adaptation relationnelle, est nécessaire pour la tâche T1, qui consiste à informer les personnes. Cela permet de s''assurer que toutes les parties prenantes sont bien informées et peuvent donc travailler efficacement ensemble.',5);
INSERT INTO "softskills" VALUES (135,'Planification','2 (Acquisition)','La planification est nécessaire pour la tâche T3, qui consiste à pré-sélectionner les fournisseurs. Cela permet de s''assurer que les fournisseurs sont choisis en temps opportun et que le projet peut donc progresser selon le planning prévu.',5);
INSERT INTO "softskills" VALUES (136,'Auto-organisation','3 (Maîtrise)','L''auto-organisation est essentielle pour gérer les tâches T1 à T4 de manière efficace et dans les délais (P1, P2). Un individu engagé, responsable et automotivé est capable de s''organiser de manière autonome pour accomplir ces tâches.',3);
INSERT INTO "softskills" VALUES (137,'Synthèse','2 (Acquisition)','La capacité de synthèse est nécessaire pour faire le rapport de faisabilité (T4). Un individu engagé, responsable et automotivé est capable de synthétiser les informations de manière claire et concise.',3);
INSERT INTO "softskills" VALUES (138,'Planification','2 (Acquisition)','La planification est nécessaire pour respecter les contraintes C1 et les performances P1 et P2. Un individu engagé, responsable et automotivé est capable de planifier ses actions en tenant compte des disponibilités des équipes et des délais à respecter.',3);
INSERT INTO "softskills" VALUES (139,'Coopération','1 (Initiation)','La coopération est nécessaire pour transmettre aux équipes (T1) et prendre en compte la disponibilité des équipes (C1). Un individu engagé, responsable et automotivé est capable de coopérer avec les autres membres de l''équipe pour réaliser ces tâches.',3);
INSERT INTO "softskills" VALUES (140,'Traitement de l’information','3 (Maîtrise)','Le traitement de l''information est crucial pour identifier les caractéristiques de la demande (T2) et analyser les contraintes techniques (T3). Un individu engagé, responsable et automotivé est capable de traiter efficacement les informations pour réaliser ces tâches.',3);
INSERT INTO "softskills" VALUES (154,'"niveau": 2,','2','',6);
INSERT INTO "softskills" VALUES (155,'"justification": "Il est important de transmettre clairement les informations relatives à l''offre aux parties prenantes."','2','',6);
INSERT INTO "softskills" VALUES (156,'"habilete": "Résolution de problèmes",','2','',6);
INSERT INTO "softskills" VALUES (157,'"justification": "La prise en compte de l''offre peut impliquer des imprévus nécessitant une approche proactive pour trouver des solutions."','2','',6);
INSERT INTO "softskills" VALUES (158,'"habilete": "Collaboration",','2','',6);
INSERT INTO "softskills" VALUES (159,'Traitement de l''information','3 (Maîtrise)','La capacité à analyser et vérifier les informations est essentielle pour garantir la conformité avec la nomenclature du catalogue.',2);
INSERT INTO "softskills" VALUES (160,'Planification','2 (Acquisition)','La planification des étapes de traitement de la demande est nécessaire pour assurer une gestion efficace des tâches.',2);
INSERT INTO "softskills" VALUES (161,'Auto-organisation','4 (Excellence)','Une excellente auto-organisation est requise pour gérer simultanément plusieurs tâches tout en respectant les délais.',2);
INSERT INTO "softskills" VALUES (162,'Coopération','3 (Maîtrise)','La collaboration avec les différents acteurs est cruciale pour collecter les informations nécessaires à la faisabilité.',2);
INSERT INTO "softskills" VALUES (163,'Flexibilité mentale','2 (Acquisition)','La capacité à s''adapter aux changements dans les demandes ou les contraintes est importante pour le traitement efficace des demandes.',2);
INSERT INTO "task_roles" VALUES (20,14,'Réalisateur');
INSERT INTO "task_roles" VALUES (42,14,'Ressource');
INSERT INTO "task_roles" VALUES (3,3,'Conseil');
INSERT INTO "task_roles" VALUES (44,13,'Réalisateur');
INSERT INTO "task_roles" VALUES (42,13,'Conseil');
INSERT INTO "task_roles" VALUES (43,13,'Approbateur');
INSERT INTO "task_roles" VALUES (46,13,'Réalisateur');
INSERT INTO "task_roles" VALUES (8,114,'Approbateur');
INSERT INTO "task_roles" VALUES (17,3,'Approbateur');
INSERT INTO "task_roles" VALUES (35,3,'Approbateur');
INSERT INTO "task_roles" VALUES (1,7,'Réalisateur');
INSERT INTO "task_tools" VALUES (39,23);
INSERT INTO "task_tools" VALUES (43,28);
INSERT INTO "task_tools" VALUES (36,17);
INSERT INTO "task_tools" VALUES (39,17);
INSERT INTO "task_tools" VALUES (2,29);
INSERT INTO "task_tools" VALUES (3,1);
INSERT INTO "task_tools" VALUES (3,3);
INSERT INTO "task_tools" VALUES (43,20);
INSERT INTO "task_tools" VALUES (46,25);
INSERT INTO "task_tools" VALUES (46,30);
INSERT INTO "task_tools" VALUES (17,31);
INSERT INTO "task_tools" VALUES (35,29);
INSERT INTO "task_tools" VALUES (35,32);
INSERT INTO "tasks" VALUES (1,'Analye de la demande','',0,2,0.0,0.0);
INSERT INTO "tasks" VALUES (2,'Vérification de la disponibilité catalogue','si catalogue',4,2,0.0,0.0);
INSERT INTO "tasks" VALUES (3,'Collecte des informations pour les faisabilité','Si produit spécifique',7,2,0.0,0.0);
INSERT INTO "tasks" VALUES (5,'Collecter les informations necessaires','',0,4,0.0,0.0);
INSERT INTO "tasks" VALUES (6,'Rédaction de l''offre','',1,4,0.0,0.0);
INSERT INTO "tasks" VALUES (8,'Envoie de l''offre','',3,4,0.0,0.0);
INSERT INTO "tasks" VALUES (9,'Prise en compte de la demande et des objection du client','','',8,0.0,0.0);
INSERT INTO "tasks" VALUES (10,'Construction d''un argumentaire','','',8,0.0,0.0);
INSERT INTO "tasks" VALUES (11,'Négogiation avec le client ','MArge de négo 15 %','',8,0.0,0.0);
INSERT INTO "tasks" VALUES (12,'Vérifier avec le client la raison du retard de paiement','','',15,0.0,0.0);
INSERT INTO "tasks" VALUES (13,'Négocier fermement pour obtnir le paiement','Acceptation paiement 30 jours','',15,0.0,0.0);
INSERT INTO "tasks" VALUES (14,'Identifier l''équipe projet','Avec team leader','',5,0.0,0.0);
INSERT INTO "tasks" VALUES (15,'Pré- Sélectionner les fourniseurs','','',5,0.0,0.0);
INSERT INTO "tasks" VALUES (17,'Etablir le planning des parties prenantes','','',5,0.0,0.0);
INSERT INTO "tasks" VALUES (18,'Mesure d''écart de résistance','',2,9,0.0,0.0);
INSERT INTO "tasks" VALUES (19,'Report des résultat sur feuille de test','',0,9,0.0,0.0);
INSERT INTO "tasks" VALUES (20,'Comparaison produits eistants','',1,9,0.0,0.0);
INSERT INTO "tasks" VALUES (21,'Analyse comparative des fournisseur','France uniquement',1,7,0.0,0.0);
INSERT INTO "tasks" VALUES (22,'Demande de cotation fournisseurs','',0,7,0.0,0.0);
INSERT INTO "tasks" VALUES (23,'Etablissement d''une feuiller de prix','',2,7,0.0,0.0);
INSERT INTO "tasks" VALUES (24,'Rapprocher le bon de commande de la facture','Vérifie fournisseur',0,13,0.0,0.0);
INSERT INTO "tasks" VALUES (25,'Etablir la facture et les pièces comptables','',1,13,0.0,0.0);
INSERT INTO "tasks" VALUES (26,'Merttre à jour la comptabilité clinet','',2,13,0.0,0.0);
INSERT INTO "tasks" VALUES (27,'Envoyer la facture','',3,13,0.0,0.0);
INSERT INTO "tasks" VALUES (28,'Préparation des conditions de test','',0,11,0.0,0.0);
INSERT INTO "tasks" VALUES (29,'Exécution des mesures demandées','utilisation des instructions',1,11,0.0,0.0);
INSERT INTO "tasks" VALUES (30,'Etablir les relevés de mesure','',2,11,0.0,0.0);
INSERT INTO "tasks" VALUES (31,'Faire la synthèse comparative des mesures','',3,11,0.0,0.0);
INSERT INTO "tasks" VALUES (32,'Identifier les caracéristiques de la demande','',0,3,0.0,0.0);
INSERT INTO "tasks" VALUES (33,'Analyser les contraintes techniques','',3,3,0.0,0.0);
INSERT INTO "tasks" VALUES (35,'Faire le rapport de faisabilité','',9,3,0.0,0.0);
INSERT INTO "tasks" VALUES (36,'Publication des pages modifiées','',13,1,10.0,0.0);
INSERT INTO "tasks" VALUES (37,'Etablir la liste des relances','','',16,0.0,0.0);
INSERT INTO "tasks" VALUES (39,'Vérifier les Ping','',9,1,30.0,0.0);
INSERT INTO "tasks" VALUES (40,'Faire le comtpe rendu de négo','','',8,0.0,0.0);
INSERT INTO "tasks" VALUES (43,'Traitement des images et photos au format web','',4,1,15.0,0.0);
INSERT INTO "tasks" VALUES (44,'finalisation de la page savoirs','',0,1,20.0,0.0);
INSERT INTO "tasks" VALUES (46,'Mise en forme de l''offre','En fonction de l''quipe',NULL,4,0.0,0.0);
INSERT INTO "tasks" VALUES (47,'Informer les personnes','Tous team',NULL,5,0.0,0.0);
INSERT INTO "tasks" VALUES (48,'Transmettre au équipes','Par mail',NULL,3,0.0,0.0);
INSERT INTO "tasks" VALUES (49,'tez','',NULL,2,0.0,0.0);
INSERT INTO "time_analysis" VALUES (2,1,'journalier',3,2,'user',1,NULL,1,'minutes',3.0,NULL,1,212);
INSERT INTO "time_analysis" VALUES (3,45,'hebdo',2,20,'role',1,NULL,1,'minutes',30.0,NULL,1,0);
INSERT INTO "time_analysis" VALUES (7,240,'hebdomadaire',4,NULL,'activity',1,NULL,3,'minutes',NULL,NULL,NULL,NULL);
INSERT INTO "time_analysis" VALUES (8,180,'hebdomadaire',2,NULL,'activity',15,NULL,1,'minutes',NULL,NULL,NULL,NULL);
INSERT INTO "time_project" VALUES (2,'test','2025-10-03 09:30:52.850116',1);
INSERT INTO "time_project" VALUES (3,'Premier Projet ABs','2025-10-03 10:02:08.377672',1);
INSERT INTO "time_project_line" VALUES (2,2,1,20.0,720.0,4);
INSERT INTO "time_project_line" VALUES (3,3,1,145.0,5040.0,2);
INSERT INTO "time_project_line" VALUES (4,3,16,20.0,3.5,3);
INSERT INTO "time_role_analysis" VALUES (2,13,NULL,NULL,'2025-10-09 07:06:14.701715','Analyse rôle');
INSERT INTO "time_role_analysis" VALUES (3,13,NULL,NULL,'2025-10-09 11:23:06.228715','Analyse rôle vDEf');
INSERT INTO "time_role_analysis" VALUES (4,13,NULL,NULL,'2025-10-09 11:25:04.225551','A WebDev v1');
INSERT INTO "time_role_line" VALUES (4,2,11,'journalier',1,NULL,0.0,1);
INSERT INTO "time_role_line" VALUES (5,2,1,'journalier',1,NULL,0.0,1);
INSERT INTO "time_role_line" VALUES (6,2,4,'mensuel',3,NULL,0.0,1);
INSERT INTO "time_role_line" VALUES (7,3,11,'journalier',1,260.0,0.0,1);
INSERT INTO "time_role_line" VALUES (8,3,1,'journalier',1,75.0,0.0,1);
INSERT INTO "time_role_line" VALUES (9,3,4,'hebdomadaire',3,40.0,0.0,1);
INSERT INTO "time_role_line" VALUES (10,4,11,'annuel',10,260.0,0.0,1);
INSERT INTO "time_role_line" VALUES (11,4,1,'mensuel',3,75.0,0.0,1);
INSERT INTO "time_role_line" VALUES (12,4,4,'hebdomadaire',6,40.0,0.0,1);
INSERT INTO "time_role_line" VALUES (13,4,2,'journalier',2,20.0,0.0,1);
INSERT INTO "time_weakness" VALUES (1,1,NULL,75.0,1440.0,'journalier',1,'internet à crash',20.0,'minutes',55.0,'minutes',1,'2025-10-09 12:38:00.120437');
INSERT INTO "tools" VALUES (1,'Check list','',1);
INSERT INTO "tools" VALUES (2,'Ficheiers produits','',1);
INSERT INTO "tools" VALUES (3,'Dossier de faisabilité','',1);
INSERT INTO "tools" VALUES (4,'Word Template','',1);
INSERT INTO "tools" VALUES (5,'PowerPoint template','',1);
INSERT INTO "tools" VALUES (6,'Liste Ingénieurs','',1);
INSERT INTO "tools" VALUES (7,'planning','',1);
INSERT INTO "tools" VALUES (8,'Base fournisseurs','',1);
INSERT INTO "tools" VALUES (9,'Logiciel de mesure','',1);
INSERT INTO "tools" VALUES (10,'feue de résultat','',1);
INSERT INTO "tools" VALUES (11,'Fichier de comparaison','',1);
INSERT INTO "tools" VALUES (12,'base des pris','',1);
INSERT INTO "tools" VALUES (13,'Feuille de prix','',1);
INSERT INTO "tools" VALUES (14,'Logicial facture','',1);
INSERT INTO "tools" VALUES (15,'Instruments de mesure','',1);
INSERT INTO "tools" VALUES (16,'relevés de mesures','',1);
INSERT INTO "tools" VALUES (17,'Base d''enregistrement des contrôles','',1);
INSERT INTO "tools" VALUES (18,'Ficheirs des spécificartions','',1);
INSERT INTO "tools" VALUES (19,'feuille de comparaison','',1);
INSERT INTO "tools" VALUES (20,'Autocad',NULL,1);
INSERT INTO "tools" VALUES (21,'Logiciel Dessin','',1);
INSERT INTO "tools" VALUES (22,'MAquettee synthèse faisabilité','',1);
INSERT INTO "tools" VALUES (23,'Interrogateur Ping','',1);
INSERT INTO "tools" VALUES (24,'wordpress','',1);
INSERT INTO "tools" VALUES (25,'Tableau des codes produits','',1);
INSERT INTO "tools" VALUES (26,'CRM Suivi client','',1);
INSERT INTO "tools" VALUES (27,'web analisys',NULL,1);
INSERT INTO "tools" VALUES (28,'Photoshop',NULL,1);
INSERT INTO "tools" VALUES (29,'Catalogue',NULL,1);
INSERT INTO "tools" VALUES (30,'Template PPT Offer',NULL,1);
INSERT INTO "tools" VALUES (31,'Canal Team Projet',NULL,1);
INSERT INTO "tools" VALUES (32,'Feasability Check',NULL,1);
INSERT INTO "training_plan" VALUES (1,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les tâches.\",\n        \"methode\": \"Atelier pratique sur la gestion autonome des projets.\",\n        \"livrables\": \"Rapport d''auto-évaluation et plan d''action personnel.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S1 - S2\",\n        \"criteres_validation\": \"Évaluation de l''autonomie par le manager.\",\n        \"jalons\": {\n          \"S2\": \"Fin de l''atelier et remise des rapports.\"\n        }\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs techniques.\",\n        \"methode\": \"Micro-learning sur les fondamentaux techniques.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S3\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\",\n        \"jalons\": {\n          \"S4\": \"Évaluation des résultats du quiz.\"\n        }\n      }\n    ],\n    \"echancier\": {\n      \"S1\": \"Début de l''atelier sur l''autonomie.\",\n      \"S2\": \"Fin de l''atelier et remise des rapports.\",\n      \"S3\": \"Début du micro-learning.\",\n      \"S4\": \"Évaluation des résultats du quiz.\",\n      \"S8\": \"Suivi des progrès et ajustements si nécessaires.\"\n    }\n  }\n}\n```"}}','2025-09-16 22:05:12');
INSERT INTO "training_plan" VALUES (2,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les tâches\",\n        \"methode\": \"Atelier pratique avec mise en situation\",\n        \"livrables\": \"Rapport de progression\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation de l''autonomie par le manager\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs spécifiques\",\n        \"methode\": \"Micro-learning sur les fondamentaux\",\n        \"livrables\": \"Quiz de validation\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Plan d''action personnalisé\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S3-S4\",\n        \"criteres_validation\": \"Feedback positif du coach\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC\",\n        \"methode\": \"Atelier collaboratif\",\n        \"livrables\": \"Guide de bonnes pratiques\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S5-S6\",\n        \"criteres_validation\": \"Évaluation des pratiques par le manager\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Atelier pratique et micro-learning\",\n      \"S4\": \"Coaching et évaluation intermédiaire\",\n      \"S6\": \"Atelier collaboratif et validation des HSC\"\n    }\n  }\n}\n```"}}','2025-09-16 22:09:17');
INSERT INTO "training_plan" VALUES (3,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans les tâches quotidiennes\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progrès sur l''autonomie\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S1 - S2\",\n        \"criteres_validation\": \"Amélioration de l''autonomie mesurée par des feedbacks réguliers\"\n      },\n      {\n        \"objectif\": \"Acquérir des connaissances de base sur les processus\",\n        \"methode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation et évaluation des connaissances\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S3 - S4\",\n        \"criteres_validation\": \"Score d''évaluation supérieur à 80%\"\n      },\n      {\n        \"objectif\": \"Développer les compétences spécifiques liées aux savoir-faire\",\n        \"methode\": \"Micro-learning avec modules en ligne\",\n        \"livrables\": \"Suivi des modules complétés\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S5 - S6\",\n        \"criteres_validation\": \"Achèvement de tous les modules avec un score d''évaluation supérieur à 75%\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC nécessaires pour le rôle\",\n        \"methode\": \"Compagnonnage avec un mentor\",\n        \"livrables\": \"Journal de bord des sessions de compagnonnage\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S7 - S8\",\n        \"criteres_validation\": \"Feedback positif du mentor sur l''application des HSC\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Fin de la première phase de coaching\",\n      \"S4\": \"Fin de l''atelier pratique\",\n      \"S8\": \"Fin du plan de formation avec validation des compétences\"\n    }\n  }\n}\n```"}}','2025-09-16 22:23:47');
INSERT INTO "training_plan" VALUES (4,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans les tâches\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progrès\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Amélioration de l''autonomie mesurée par des retours d''expérience\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"Acquérir des bases solides dans les savoirs manquants\",\n        \"methode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Évaluation des connaissances acquises via un test\",\n        \"jalon\": \"S4\"\n      },\n      {\n        \"objectif\": \"Renforcer les savoir-faire spécifiques\",\n        \"methode\": \"Micro-learning\",\n        \"livrables\": \"Module de formation en ligne\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"Feedback sur l''application des savoir-faire dans le travail quotidien\",\n        \"jalon\": \"S8\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Coaching individuel sur l''autonomie\",\n      \"S4\": \"Atelier pratique sur les bases des savoirs\",\n      \"S8\": \"Module de micro-learning sur les savoir-faire\"\n    }\n  }\n}\n```"}}','2025-10-01 09:10:49');
INSERT INTO "training_plan" VALUES (5,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs\",\n        \"méthode\": \"Atelier pratique\",\n        \"livrables\": \"Guide d''autonomie\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation de l''autonomie par un quiz\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs\",\n        \"méthode\": \"Micro-learning\",\n        \"livrables\": \"Modules de formation en ligne\",\n        \"durée_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Test de connaissances\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire spécifiques\",\n        \"méthode\": \"Coaching individuel\",\n        \"livrables\": \"Plan de développement personnel\",\n        \"durée_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback du coach\"\n      },\n      {\n        \"objectif\": \"Améliorer les HSC\",\n        \"méthode\": \"Atelier collaboratif\",\n        \"livrables\": \"Plan d''action HSC\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"Évaluation des HSC par les pairs\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Ateliers et modules de formation\",\n      \"S4\": \"Coaching et feedback\",\n      \"S8\": \"Évaluation finale et ajustements\"\n    }\n  }\n}\n```"}}','2025-10-01 13:06:01');
INSERT INTO "training_plan" VALUES (6,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés\",\n        \"methode\": \"Atelier pratique sur les savoirs spécifiques\",\n        \"livrables\": \"Rapport d''atelier et évaluation des compétences\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation des compétences acquises par un test pratique\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs\",\n        \"methode\": \"Micro-learning sur les fondamentaux\",\n        \"livrables\": \"Modules de micro-learning complétés\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Quiz de validation des connaissances\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques\",\n        \"methode\": \"Coaching individuel avec un expert\",\n        \"livrables\": \"Plan de développement personnel et feedback\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback du coach sur les progrès réalisés\"\n      },\n      {\n        \"objectif\": \"Évaluer et ajuster les compétences HSC\",\n        \"methode\": \"Séance de compagnonnage\",\n        \"livrables\": \"Rapport d''évaluation des HSC\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"Évaluation des HSC par le manager\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching et suivi\",\n      \"S8\": \"Évaluation finale\"\n    }\n  }\n}\n```"}}','2025-10-01 14:54:25');
INSERT INTO "training_plan" VALUES (7,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés.\",\n        \"methode\": \"Atelier pratique sur les savoirs spécifiques.\",\n        \"livrables\": \"Rapport d''évaluation des compétences acquises.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation positive des compétences par le formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"methode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire spécifiques.\",\n        \"methode\": \"Coaching individuel avec un expert.\",\n        \"livrables\": \"Plan d''action personnalisé.\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif de l''expert sur les progrès réalisés.\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching individuel\",\n      \"S8\": \"Évaluation finale des compétences.\"\n    }\n  }\n}\n```"}}','2025-10-01 15:04:46');
INSERT INTO "training_plan" VALUES (8,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés.\",\n        \"methode\": \"Atelier pratique sur les savoirs spécifiques.\",\n        \"livrables\": \"Rapport d''atelier et évaluation des compétences.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation positive des participants sur l''autonomie.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"methode\": \"Micro-learning sur les concepts fondamentaux.\",\n        \"livrables\": \"Modules de micro-learning complétés.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% sur les quiz de fin de module.\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques.\",\n        \"methode\": \"Coaching individuel avec un mentor.\",\n        \"livrables\": \"Feedback du mentor et plan d''action personnel.\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Amélioration mesurable dans les tâches pratiques.\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC.\",\n        \"methode\": \"Atelier collaboratif sur les HSC.\",\n        \"livrables\": \"Guide pratique sur les HSC.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Évaluation des participants sur la mise en pratique des HSC.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching et ateliers HSC\",\n      \"S8\": \"Évaluation finale et feedback\"\n    }\n  }\n}\n```"}}','2025-10-01 15:05:33');
INSERT INTO "training_plan" VALUES (9,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés.\",\n        \"méthode\": \"Atelier pratique avec études de cas.\",\n        \"livrables\": \"Rapport d''analyse des cas traités.\",\n        \"durée_estimée\": \"2 semaines\",\n        \"séquencement\": \"S2\",\n        \"critères_de_validation\": \"Évaluation des cas par le formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs spécifiques.\",\n        \"méthode\": \"Micro-learning sur les concepts clés.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"durée_estimée\": \"1 semaine\",\n        \"séquencement\": \"S4\",\n        \"critères_de_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques.\",\n        \"méthode\": \"Coaching individuel sur des tâches spécifiques.\",\n        \"livrables\": \"Feedback écrit sur les performances.\",\n        \"durée_estimée\": \"3 semaines\",\n        \"séquencement\": \"S4 à S8\",\n        \"critères_de_validation\": \"Amélioration mesurable des performances.\"\n      }\n    ],\n    \"échéancier\": {\n      \"S2\": \"Atelier pratique\",\n      \"S4\": \"Micro-learning et début du coaching\",\n      \"S8\": \"Évaluation finale des compétences\"\n    }\n  }\n}\n```"}}','2025-10-01 15:06:12');
INSERT INTO "training_plan" VALUES (10,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans l''activité\",\n        \"méthode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progrès\",\n        \"durée_estimée\": \"2 semaines\",\n        \"séquencement\": \"S2\",\n        \"critères_de_validation\": \"Amélioration de l''autonomie mesurée par des indicateurs de performance\"\n      },\n      {\n        \"objectif\": \"Acquérir des compétences de base supplémentaires\",\n        \"méthode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation\",\n        \"durée_estimée\": \"2 semaines\",\n        \"séquencement\": \"S4\",\n        \"critères_de_validation\": \"Évaluation des compétences acquises par un test\"\n      },\n      {\n        \"objectif\": \"Développer des savoir-faire spécifiques\",\n        \"méthode\": \"Micro-learning\",\n        \"livrables\": \"Module de formation en ligne\",\n        \"durée_estimée\": \"1 semaine\",\n        \"séquencement\": \"S8\",\n        \"critères_de_validation\": \"Taux de complétion du module et évaluation finale\"\n      }\n    ],\n    \"échéancier\": {\n      \"S2\": \"Coaching individuel\",\n      \"S4\": \"Atelier pratique\",\n      \"S8\": \"Micro-learning\"\n    }\n  }\n}\n```"}}','2025-10-01 15:11:52');
INSERT INTO "training_plan" VALUES (11,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans l''utilisation des outils spécifiques.\",\n        \"méthode\": \"Atelier pratique avec mise en situation.\",\n        \"livrables\": \"Rapport d''auto-évaluation et feedback des pairs.\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Satisfaction des participants et amélioration des performances mesurées.\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases théoriques nécessaires à l''activité.\",\n        \"méthode\": \"Micro-learning via modules en ligne.\",\n        \"livrables\": \"Certificat de complétion des modules.\",\n        \"durée_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Achèvement des modules avec un score minimum de 80%.\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"Développer des compétences avancées dans les savoir-faire identifiés.\",\n        \"méthode\": \"Coaching individuel avec un expert.\",\n        \"livrables\": \"Plan de développement personnel et rapport de progrès.\",\n        \"durée_estimee\": \"4 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Amélioration des performances dans les tâches spécifiques.\",\n        \"jalon\": \"S4\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et modules de micro-learning\",\n      \"S4\": \"Coaching et suivi des progrès\",\n      \"S8\": \"Évaluation finale des compétences acquises\"\n    }\n  }\n}\n```"}}','2025-10-01 15:18:47');
INSERT INTO "training_plan" VALUES (12,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d’exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés.\",\n        \"méthode\": \"Atelier pratique sur les savoirs spécifiques.\",\n        \"livrables\": \"Rapport d''évaluation des compétences acquises.\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation des compétences par un formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"méthode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"durée_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques.\",\n        \"méthode\": \"Coaching individuel sur les savoir-faire.\",\n        \"livrables\": \"Plan d''action personnalisé.\",\n        \"durée_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif du coach.\"\n      },\n      {\n        \"objectif\": \"Améliorer les HSC.\",\n        \"méthode\": \"Compagnonnage avec un expert.\",\n        \"livrables\": \"Rapport de suivi de progression.\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Évaluation par l''expert.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning.\",\n      \"S4\": \"Coaching et compagnonnage.\",\n      \"S8\": \"Évaluation finale des compétences.\"\n    }\n  }\n}\n```"}}','2025-10-01 15:22:13');
INSERT INTO "training_plan" VALUES (13,111,13,11,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activité (démo)", "performances_cibles": ["Qualité", "Délais"], "hypotheses": []}, "axes": [{"intitule": "Mise à niveau Savoirs", "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas d''exercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer les compétences en HSC\",\n        \"méthode\": \"Atelier pratique\",\n        \"livrables\": \"Guide de bonnes pratiques en HSC\",\n        \"durée_estimée\": \"2 semaines\",\n        \"séquencement\": \"S2\",\n        \"critères_de_validation\": \"Évaluation des participants sur les connaissances acquises\"\n      },\n      {\n        \"objectif\": \"Renforcer les savoir-faire spécifiques\",\n        \"méthode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progrès\",\n        \"durée_estimée\": \"3 semaines\",\n        \"séquencement\": \"S4\",\n        \"critères_de_validation\": \"Amélioration des performances mesurées\"\n      },\n      {\n        \"objectif\": \"Consolider les savoirs théoriques\",\n        \"méthode\": \"Micro-learning\",\n        \"livrables\": \"Quiz de validation\",\n        \"durée_estimée\": \"1 semaine\",\n        \"séquencement\": \"S8\",\n        \"critères_de_validation\": \"Taux de réussite au quiz supérieur à 80%\"\n      }\n    ],\n    \"échéancier\": {\n      \"S2\": \"Atelier pratique sur HSC\",\n      \"S4\": \"Coaching individuel sur savoir-faire\",\n      \"S8\": \"Micro-learning sur savoirs théoriques\"\n    }\n  }\n}\n```"}}','2025-12-04 14:50:31');
INSERT INTO "user_activity_plans" VALUES (1,111,1,13,'{"axes": [{"intitule": "Mise à niveau Savoirs", "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}], "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"contenus_recommandes": ["Module interne A", "Cas d’exercice"], "criteres_de_validation": ["0 erreur sur cas test"], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "methodes": ["micro-learning", "atelier pratique"], "option": "Judicieuse", "prerequis": []}]}], "contexte_synthetique": {"activite": "Activité (démo)", "hypotheses": [], "performances_cibles": ["Qualité", "Délais"]}, "meta": {"raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer l''autonomie dans les savoirs identifiés.\",\n        \"méthode\": \"Atelier pratique sur les savoirs spécifiques.\",\n        \"livrables\": \"Rapport d''évaluation des compétences acquises.\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Évaluation des compétences par un formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"méthode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"durée_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"Développer les savoir-faire pratiques.\",\n        \"méthode\": \"Coaching individuel sur les savoir-faire.\",\n        \"livrables\": \"Plan d''action personnalisé.\",\n        \"durée_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif du coach.\"\n      },\n      {\n        \"objectif\": \"Améliorer les HSC.\",\n        \"méthode\": \"Compagnonnage avec un expert.\",\n        \"livrables\": \"Rapport de suivi de progression.\",\n        \"durée_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Évaluation par l''expert.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning.\",\n      \"S4\": \"Coaching et compagnonnage.\",\n      \"S8\": \"Évaluation finale des compétences.\"\n    }\n  }\n}\n```", "source": "fallback_parse_error"}, "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "type": "PLAN_DE_FORMATION"}','2025-10-01T15:11:59','2025-10-01T15:22:21');
INSERT INTO "user_activity_plans" VALUES (2,111,11,13,'{"axes": [{"intitule": "Mise à niveau Savoirs", "jalons": [{"semaine": 2, "verif": "mini-évaluation"}, {"semaine": 4, "verif": "KPI intermédiaires"}, {"semaine": 8, "verif": "KPI finaux"}], "justification": "Écarts détectés sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts clés"], "parcours": [{"contenus_recommandes": ["Module interne A", "Cas d''exercice"], "criteres_de_validation": ["0 erreur sur cas test"], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliquée"], "methodes": ["micro-learning", "atelier pratique"], "option": "Judicieuse", "prerequis": []}]}], "contexte_synthetique": {"activite": "Activité (démo)", "hypotheses": [], "performances_cibles": ["Qualité", "Délais"]}, "meta": {"raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Améliorer les compétences en HSC\",\n        \"méthode\": \"Atelier pratique\",\n        \"livrables\": \"Guide de bonnes pratiques en HSC\",\n        \"durée_estimée\": \"2 semaines\",\n        \"séquencement\": \"S2\",\n        \"critères_de_validation\": \"Évaluation des participants sur les connaissances acquises\"\n      },\n      {\n        \"objectif\": \"Renforcer les savoir-faire spécifiques\",\n        \"méthode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progrès\",\n        \"durée_estimée\": \"3 semaines\",\n        \"séquencement\": \"S4\",\n        \"critères_de_validation\": \"Amélioration des performances mesurées\"\n      },\n      {\n        \"objectif\": \"Consolider les savoirs théoriques\",\n        \"méthode\": \"Micro-learning\",\n        \"livrables\": \"Quiz de validation\",\n        \"durée_estimée\": \"1 semaine\",\n        \"séquencement\": \"S8\",\n        \"critères_de_validation\": \"Taux de réussite au quiz supérieur à 80%\"\n      }\n    ],\n    \"échéancier\": {\n      \"S2\": \"Atelier pratique sur HSC\",\n      \"S4\": \"Coaching individuel sur savoir-faire\",\n      \"S8\": \"Micro-learning sur savoirs théoriques\"\n    }\n  }\n}\n```", "source": "fallback_parse_error"}, "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "modéré", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "type": "PLAN_DE_FORMATION"}','2025-12-04T14:50:34','2025-12-04T14:50:34');
INSERT INTO "user_competencies" VALUES (121,15,'2023-10-01',2);
INSERT INTO "user_competencies" VALUES (122,16,'2023-10-01',1);
INSERT INTO "user_competencies" VALUES (123,17,'2023-10-01',3);
INSERT INTO "user_competencies" VALUES (124,18,'2023-10-01',1);
INSERT INTO "user_competencies" VALUES (125,19,'2023-10-01',2);
INSERT INTO "user_competencies" VALUES (126,20,'2023-10-01',3);
INSERT INTO "user_competencies" VALUES (127,16,'2023-10-01',1);
INSERT INTO "user_competencies" VALUES (128,17,'2023-10-01',2);
INSERT INTO "user_competencies" VALUES (129,18,'2023-10-01',1);
INSERT INTO "user_roles" VALUES (114,1);
INSERT INTO "user_roles" VALUES (112,10);
INSERT INTO "user_roles" VALUES (210,1);
INSERT INTO "user_roles" VALUES (211,19);
INSERT INTO "user_roles" VALUES (212,1);
INSERT INTO "user_roles" VALUES (211,20);
INSERT INTO "user_roles" VALUES (213,1);
INSERT INTO "user_roles" VALUES (214,1);
INSERT INTO "user_roles" VALUES (211,1);
INSERT INTO "user_roles" VALUES (212,17);
INSERT INTO "user_roles" VALUES (212,9);
INSERT INTO "user_roles" VALUES (212,19);
INSERT INTO "user_roles" VALUES (201,15);
INSERT INTO "user_roles" VALUES (201,22);
INSERT INTO "user_roles" VALUES (131,5);
INSERT INTO "user_roles" VALUES (111,7);
INSERT INTO "user_roles" VALUES (111,3);
INSERT INTO "user_roles" VALUES (111,4);
INSERT INTO "user_roles" VALUES (111,15);
INSERT INTO "user_roles" VALUES (111,2);
INSERT INTO "user_roles" VALUES (111,13);
INSERT INTO "user_roles" VALUES (110,17);
INSERT INTO "user_roles" VALUES (110,16);
INSERT INTO "user_roles" VALUES (110,114);
INSERT INTO "user_roles" VALUES (110,11);
INSERT INTO "user_roles" VALUES (110,12);
INSERT INTO "user_roles" VALUES (110,13);
INSERT INTO "user_roles" VALUES (129,10);
INSERT INTO "user_roles" VALUES (205,2);
INSERT INTO "users" VALUES (0,'Bob','Dupont',40,'bob.dupont@example.com','scrypt:32768:8:1$hashbob',NULL,'user',1);
INSERT INTO "users" VALUES (110,'Alice','Bernard',35,'alice.bernard@example.com','scrypt:32768:8:1$Uu2hcSYyaPZoHdPA$47c2a5ffaa44a48733316e321fda9a096c50cb837dd6cd1e82d198493e073479c4f711d50062ce3f945e259abffe2607495472c7d72b139675d0561ddc5b3ba6',114,'administrateur',1);
INSERT INTO "users" VALUES (111,'Bob','Dupont',40,'bob.dupont@example.com','scrypt:32768:8:1$YusH80tOxLkLS9vQ$16d1d7abb4820c78560c251d51b192918fa194e7e97cfd19d0db872295b58f1d93233d6005ce4ebc5d2949c0df05362d1e74bc74c1a78c3280d5d1723717c710',114,'user',1);
INSERT INTO "users" VALUES (112,'Claude','Moreau',50,'claude.moreau@example.com','scrypt:32768:8:1$randomhash1',114,'user',1);
INSERT INTO "users" VALUES (113,'Diana','Leroux',45,'diana.leroux@example.com','scrypt:32768:8:1$randomhash2',NULL,'user',1);
INSERT INTO "users" VALUES (114,'Maël','Girardin',20,'mael.pierre.girardin@icloud.com','scrypt:32768:8:1$A5YSvJsMRLWEXgPP$c7e873c503ce0b551ae7e4745b80cf89389f949c5c62faf514008868ce0cc0a444d99a1464282968307285dfc8767476c6f4fa753f34a0d92364bb99d7f979a4',114,'administrateur',1);
INSERT INTO "users" VALUES (121,'Céline','Martin',28,'celine.martin@example.com','scrypt:32768:8:1$hashceline',NULL,'user',1);
INSERT INTO "users" VALUES (122,'David','Morin',32,'david.morin@example.com','scrypt:32768:8:1$hashdavid',NULL,'user',1);
INSERT INTO "users" VALUES (123,'Eva','Leroy',29,'eva.leroy@example.com','scrypt:32768:8:1$hasheva',NULL,'user',1);
INSERT INTO "users" VALUES (124,'Frank','Lemaire',33,'frank.lemaire@example.com','scrypt:32768:8:1$hashfrank',NULL,'user',1);
INSERT INTO "users" VALUES (125,'George','Dubois',37,'george.dubois@example.com','scrypt:32768:8:1$hashgeorge',NULL,'user',1);
INSERT INTO "users" VALUES (126,'Hanna','Noir',26,'hanna.noir@example.com','scrypt:32768:8:1$hashhanna',114,'user',1);
INSERT INTO "users" VALUES (127,'Ibrahim','Khan',31,'ibrahim.khan@example.com','scrypt:32768:8:1$hashibrahim',110,'user',1);
INSERT INTO "users" VALUES (128,'Juliette','Fischer',34,'juliette.fischer@example.com','scrypt:32768:8:1$hashjuliette',NULL,'user',1);
INSERT INTO "users" VALUES (129,'Kevin','Lévesque',28,'kevin.levesque@example.com','scrypt:32768:8:1$hashkevin',114,'user',1);
INSERT INTO "users" VALUES (130,'Lucie','Simon',29,'lucie.simon@example.com','scrypt:32768:8:1$hashlucie',114,'user',1);
INSERT INTO "users" VALUES (131,'Marc','Brun',29,'marc.brun@example.com','scrypt:32768:8:1$hashmarc',NULL,'user',1);
INSERT INTO "users" VALUES (201,'Hugette','Bidule',35,'hugette.bidule@example.com','scrypt:32768:8:1$hashalice',NULL,'user',1);
INSERT INTO "users" VALUES (203,'Claude','Moreau',50,'claude.moreau@example.com','scrypt:32768:8:1$hashclaude',NULL,'user',1);
INSERT INTO "users" VALUES (204,'Diana','Leroux',45,'diana.leroux@example.com','scrypt:32768:8:1$hashdiana',NULL,'user',1);
INSERT INTO "users" VALUES (205,'huge','Berne',35,'alice.bernard@example.com','scrypt:...',NULL,'user',1);
INSERT INTO "users" VALUES (206,'Céline','Martin',28,'celine.martin@example.com','scrypt:...',NULL,'user',1);
INSERT INTO "users" VALUES (207,'David','Morin',32,'david.morin@example.com','scrypt:...',NULL,'user',1);
INSERT INTO "users" VALUES (208,'Eva','Leroy',29,'eva.leroy@example.com','scrypt:...',NULL,'user',1);
INSERT INTO "users" VALUES (209,'Frank','Lemaire',33,'frank.lemaire@example.com','scrypt:...',NULL,'user',1);
INSERT INTO "users" VALUES (210,'evannn','cikacz',20,'evan.cikacz@orange.fr','scrypt:32768:8:1$ILTE19xbNMhlmaFn$21e2491a552c4f39b8d7b2a4099658d87324b9d5139e3582255ae1cbe3a32f42c89ee22843a459d21732c0a8ac78e5de0d3390db97427af7dd2ab70c3c57a675',NULL,'user',1);
INSERT INTO "users" VALUES (211,'Hubert','GRANDJEAN',21,'h.grandjean@afdec.fr','123456',114,'administrateur',1);
INSERT INTO "users" VALUES (212,'test','test',20,'mael.pierre.girardin@icloud.com','123456',NULL,'user',1);
CREATE INDEX IF NOT EXISTS "idx_activities_delay" ON "activities" (
	"delay_minutes"
);
CREATE INDEX IF NOT EXISTS "idx_activities_duration" ON "activities" (
	"duration_minutes"
);
CREATE INDEX IF NOT EXISTS "idx_activities_entity_id" ON "activities" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_data_entity_id" ON "data" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_links_entity_id" ON "links" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_perf_pers_user_activity" ON "performance_personnalisee" (
	"user_id",
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_pph_perf_changed" ON "performance_personnalisee_historique" (
	"performance_id",
	"changed_at"
);
CREATE INDEX IF NOT EXISTS "idx_pph_user_act" ON "performance_personnalisee_historique" (
	"user_id",
	"activity_id",
	"changed_at"
);
CREATE INDEX IF NOT EXISTS "idx_prerequis_item" ON "prerequis_comment" (
	"item_type",
	"item_id"
);
CREATE INDEX IF NOT EXISTS "idx_prerequis_user_act" ON "prerequis_comment" (
	"user_id",
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_roles_entity_id" ON "roles" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_tasks_activity" ON "tasks" (
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_time_project_entity_id" ON "time_project" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_tools_entity_id" ON "tools" (
	"entity_id"
);
CREATE INDEX IF NOT EXISTS "idx_tprj_line_project" ON "time_project_line" (
	"project_id"
);
CREATE INDEX IF NOT EXISTS "idx_training_plan_user_role_act" ON "training_plan" (
	"user_id",
	"role_id",
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_trline_activity" ON "time_role_line" (
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_trline_role_analysis" ON "time_role_line" (
	"role_analysis_id"
);
CREATE INDEX IF NOT EXISTS "idx_tweak_act" ON "time_weakness" (
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_tweak_task" ON "time_weakness" (
	"task_id"
);
CREATE INDEX IF NOT EXISTS "idx_uap_activity" ON "user_activity_plans" (
	"activity_id"
);
CREATE INDEX IF NOT EXISTS "idx_uap_user" ON "user_activity_plans" (
	"user_id"
);
CREATE INDEX IF NOT EXISTS "idx_users_entity_id" ON "users" (
	"entity_id"
);
CREATE UNIQUE INDEX IF NOT EXISTS "ix_activities_shape_id" ON "activities" (
	"shape_id"
);
CREATE UNIQUE INDEX IF NOT EXISTS "ix_data_shape_id" ON "data" (
	"shape_id"
);
COMMIT;
